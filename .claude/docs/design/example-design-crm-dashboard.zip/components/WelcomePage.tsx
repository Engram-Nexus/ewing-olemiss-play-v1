import { Button } from "./ui/button"
import { Card, CardContent, CardHeader } from "./ui/card"

interface WelcomePageProps {
  onSignIn: () => void
  onSignUp: () => void
}

export function WelcomePage({ onSignIn, onSignUp }: WelcomePageProps) {
  return (
    <div style={{
      width: '100%',
      maxWidth: '400px',
      display: 'flex',
      flexDirection: 'column',
      gap: '24px'
    }}>
      {/* Logo/Brand Section */}
      <div style={{
        textAlign: 'center',
        marginBottom: '32px'
      }}>
        <div style={{
          width: '80px',
          height: '80px',
          backgroundColor: 'var(--primary)',
          borderRadius: 'var(--radius-card)',
          margin: '0 auto 24px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: 'var(--elevation-sm)'
        }}>
          <span style={{
            fontSize: '32px',
            fontWeight: 'var(--font-weight-bold)',
            color: 'var(--primary-foreground)'
          }}>
            C
          </span>
        </div>
        <h1 style={{
          fontSize: 'var(--text-h1)',
          fontWeight: 'var(--font-weight-bold)',
          color: 'var(--foreground)',
          margin: '0 0 8px 0'
        }}>
          Welcome to Clerk
        </h1>
        <p style={{
          fontSize: 'var(--text-base)',
          color: 'var(--muted-foreground)',
          margin: 0
        }}>
          Secure authentication made simple
        </p>
      </div>

      {/* Action Cards */}
      <Card style={{
        backgroundColor: 'var(--card)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius-card)',
        boxShadow: 'var(--elevation-sm)'
      }}>
        <CardHeader style={{
          textAlign: 'center',
          paddingBottom: '16px'
        }}>
          <h2 style={{
            fontSize: 'var(--text-h3)',
            fontWeight: 'var(--font-weight-semibold)',
            color: 'var(--card-foreground)',
            margin: 0
          }}>
            Get Started
          </h2>
        </CardHeader>
        <CardContent style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '16px'
        }}>
          <Button
            onClick={onSignUp}
            style={{
              backgroundColor: 'var(--primary)',
              color: 'var(--primary-foreground)',
              border: 'none',
              borderRadius: 'var(--radius-button)',
              padding: '16px 24px',
              fontSize: 'var(--text-base)',
              fontWeight: 'var(--font-weight-medium)',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              width: '100%'
            }}
          >
            Create Account
          </Button>
          
          <Button
            onClick={onSignIn}
            style={{
              backgroundColor: 'var(--secondary)',
              color: 'var(--secondary-foreground)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius-button)',
              padding: '16px 24px',
              fontSize: 'var(--text-base)',
              fontWeight: 'var(--font-weight-medium)',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              width: '100%'
            }}
          >
            Sign In
          </Button>
        </CardContent>
      </Card>

      {/* Features */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '16px',
        marginTop: '24px'
      }}>
        {[
          { icon: '🔒', title: 'Secure', desc: 'Enterprise-grade security' },
          { icon: '⚡', title: 'Fast', desc: 'Lightning-fast authentication' },
          { icon: '🛡️', title: 'Protected', desc: 'Multi-factor authentication' },
          { icon: '🌐', title: 'Universal', desc: 'Works everywhere' }
        ].map((feature, index) => (
          <div
            key={index}
            style={{
              backgroundColor: 'var(--card)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius)',
              padding: '16px',
              textAlign: 'center',
              transition: 'all 0.2s ease'
            }}
          >
            <div style={{ fontSize: '24px', marginBottom: '8px' }}>
              {feature.icon}
            </div>
            <h4 style={{
              fontSize: 'var(--text-h4)',
              fontWeight: 'var(--font-weight-semibold)',
              color: 'var(--foreground)',
              margin: '0 0 4px 0'
            }}>
              {feature.title}
            </h4>
            <p style={{
              fontSize: 'var(--text-label)',
              color: 'var(--muted-foreground)',
              margin: 0
            }}>
              {feature.desc}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}