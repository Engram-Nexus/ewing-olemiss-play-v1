import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Badge } from "./ui/badge"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar"
import { Progress } from "./ui/progress"
import { Switch } from "./ui/switch"
import { Separator } from "./ui/separator"
import { ShimmerMenuItem } from "./ShimmerMenuItem"
import { 
  Home, 
  Users, 
  Calendar, 
  Mail, 
  Phone, 
  Settings, 
  BarChart3, 
  FileText,
  Search,
  Plus,
  Edit,
  Trash,
  Download
} from "lucide-react"

const colorTokens = [
  { name: "Primary", value: "var(--primary)", class: "bg-primary", textClass: "text-primary-foreground" },
  { name: "Secondary", value: "var(--secondary)", class: "bg-secondary", textClass: "text-secondary-foreground" },
  { name: "Muted", value: "var(--muted)", class: "bg-muted", textClass: "text-muted-foreground" },
  { name: "Accent", value: "var(--accent)", class: "bg-accent", textClass: "text-accent-foreground" },
  { name: "Destructive", value: "var(--destructive)", class: "bg-destructive", textClass: "text-destructive-foreground" },
  { name: "Background", value: "var(--background)", class: "bg-background border", textClass: "text-foreground" },
  { name: "Card", value: "var(--card)", class: "bg-card border", textClass: "text-card-foreground" },
]

const typographyExamples = [
  { tag: "h1", text: "Heading 1", description: "Main page titles" },
  { tag: "h2", text: "Heading 2", description: "Section headers" },
  { tag: "h3", text: "Heading 3", description: "Subsection headers" },
  { tag: "h4", text: "Heading 4", description: "Component titles" },
  { tag: "p", text: "Body text", description: "Regular paragraph text" },
  { tag: "label", text: "Label text", description: "Form labels and UI labels" },
]

const spacingScale = [
  { name: "xs", value: "0.25rem", class: "w-1 h-4" },
  { name: "sm", value: "0.5rem", class: "w-2 h-4" },
  { name: "md", value: "1rem", class: "w-4 h-4" },
  { name: "lg", value: "1.5rem", class: "w-6 h-4" },
  { name: "xl", value: "2rem", class: "w-8 h-4" },
  { name: "2xl", value: "3rem", class: "w-12 h-4" },
  { name: "3xl", value: "4rem", class: "w-16 h-4" },
]

const iconSet = [
  Home, Users, Calendar, Mail, Phone, Settings, BarChart3, FileText,
  Search, Plus, Edit, Trash, Download
]

export function StyleGuidePage() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2>Style Guide</h2>
        <p className="text-muted-foreground mt-2">
          Design system documentation for the CRM application
        </p>
      </div>

      {/* Colors */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle>Color Palette</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {colorTokens.map((color) => (
              <div key={color.name} className="space-y-2">
                <div className={`${color.class} ${color.textClass} p-4 rounded-lg flex items-center justify-center`}>
                  <span className="font-medium">{color.name}</span>
                </div>
                <div className="text-sm">
                  <div className="font-medium">{color.name}</div>
                  <div className="text-muted-foreground font-mono text-xs">{color.value}</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Typography */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle>Typography</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            {typographyExamples.map((example) => (
              <div key={example.tag} className="flex items-center gap-8">
                <div className="w-24 text-sm text-muted-foreground font-mono">
                  &lt;{example.tag}&gt;
                </div>
                <div className="flex-1">
                  {example.tag === "h1" && <h1>{example.text}</h1>}
                  {example.tag === "h2" && <h2>{example.text}</h2>}
                  {example.tag === "h3" && <h3>{example.text}</h3>}
                  {example.tag === "h4" && <h4>{example.text}</h4>}
                  {example.tag === "p" && <p>{example.text}</p>}
                  {example.tag === "label" && <label>{example.text}</label>}
                </div>
                <div className="text-sm text-muted-foreground">
                  {example.description}
                </div>
              </div>
            ))}
          </div>
          
          <Separator />
          
          <div>
            <h4 className="mb-4">Font Weights</h4>
            <div className="space-y-2">
              <p className="font-normal">Font Normal (400) - Regular body text</p>
              <p className="font-medium">Font Medium (500) - Headings and labels</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Components */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle>Components</CardTitle>
        </CardHeader>
        <CardContent className="space-y-8">
          {/* Buttons */}
          <div>
            <h4 className="mb-4">Buttons</h4>
            <div className="flex flex-wrap gap-4">
              <Button>Primary Button</Button>
              <Button variant="secondary">Secondary Button</Button>
              <Button variant="outline">Outline Button</Button>
              <Button variant="ghost">Ghost Button</Button>
              <Button variant="destructive">Destructive Button</Button>
              <Button size="sm">Small Button</Button>
              <Button size="lg">Large Button</Button>
            </div>
          </div>

          <Separator />

          {/* Badges */}
          <div>
            <h4 className="mb-4">Badges</h4>
            <div className="flex flex-wrap gap-4">
              <Badge>Default Badge</Badge>
              <Badge variant="secondary">Secondary Badge</Badge>
              <Badge variant="outline">Outline Badge</Badge>
              <Badge variant="destructive">Destructive Badge</Badge>
              <Badge className="bg-green-100 text-green-800">Custom Badge</Badge>
            </div>
          </div>

          <Separator />

          {/* Form Elements */}
          <div>
            <h4 className="mb-4">Form Elements</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl">
              <div className="space-y-2">
                <Label htmlFor="demo-input">Input Field</Label>
                <Input id="demo-input" placeholder="Enter text here..." />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="demo-search">Search Input</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input id="demo-search" placeholder="Search..." className="pl-10" />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Switch id="demo-switch" />
                <Label htmlFor="demo-switch">Enable notifications</Label>
              </div>

              <div className="space-y-2">
                <Label>Progress Bar</Label>
                <Progress value={60} />
              </div>
            </div>
          </div>

          <Separator />

          {/* ShimmerMenuItem */}
          <div>
            <h4 className="mb-4">Shimmer Menu Item</h4>
            <p className="text-sm text-muted-foreground mb-6">
              Custom menu item component with Apple-inspired shimmer animations for sidebar navigation.
            </p>
            
            <div className="space-y-6">
              {/* Component Examples */}
              <div>
                <Label className="text-sm font-medium mb-3 block">Component States</Label>
                <div className="bg-muted/30 p-6 rounded-lg space-y-3 max-w-sm">
                  <div className="p-1 bg-white/20 rounded-lg">
                    <ShimmerMenuItem
                      icon={Home}
                      title="Active Item (with shimmer)"
                      isActive={true}
                      onClick={() => {}}
                    />
                  </div>
                  <ShimmerMenuItem
                    icon={Users}
                    title="Inactive Item (hover for effect)"
                    isActive={false}
                    onClick={() => {}}
                  />
                  <ShimmerMenuItem
                    icon={Calendar}
                    title="Another Inactive Item"
                    isActive={false}
                    onClick={() => {}}
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  <strong>Debug:</strong> The active item should show a continuous left-to-right shimmer animation.
                  Hover over inactive items to see the hover shimmer effect.
                </p>
              </div>

              {/* Props Documentation */}
              <div>
                <Label className="text-sm font-medium mb-3 block">Component Props</Label>
                <div className="bg-muted/20 p-4 rounded-lg">
                  <pre className="text-xs text-muted-foreground font-mono">
{`interface ShimmerMenuItemProps {
  icon: LucideIcon        // Icon component from lucide-react
  title: string          // Display text for the menu item
  isActive: boolean      // Controls active state and shimmer
  onClick: () => void    // Click handler function
}`}
                  </pre>
                </div>
              </div>

              {/* Animation Details */}
              <div>
                <Label className="text-sm font-medium mb-3 block">Animation Details</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="bg-muted/20 p-4 rounded-lg">
                    <div className="font-medium mb-2">Active State Shimmer</div>
                    <ul className="text-muted-foreground space-y-1">
                      <li>• Continuous 3-second animation loop</li>
                      <li>• Translucent white overlay effect</li>
                      <li>• Moves from left to right across button</li>
                      <li>• Creates premium glass-like effect</li>
                    </ul>
                  </div>
                  <div className="bg-muted/20 p-4 rounded-lg">
                    <div className="font-medium mb-2">Hover State Shimmer</div>
                    <ul className="text-muted-foreground space-y-1">
                      <li>• Single 1.5-second animation on hover</li>
                      <li>• Subtle white/10 opacity overlay</li>
                      <li>• Provides interactive feedback</li>
                      <li>• Enhances discoverability</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Usage Guidelines */}
              <div>
                <Label className="text-sm font-medium mb-3 block">Usage Guidelines</Label>
                <div className="bg-muted/20 p-4 rounded-lg">
                  <ul className="text-sm text-muted-foreground space-y-2">
                    <li>• <strong>Primary use case:</strong> Navigation menu items in sidebars</li>
                    <li>• <strong>Active state:</strong> Indicates current page/section with continuous shimmer</li>
                    <li>• <strong>Interactive feedback:</strong> Hover shimmer enhances user experience</li>
                    <li>• <strong>Accessibility:</strong> Maintains focus states and keyboard navigation</li>
                    <li>• <strong>Performance:</strong> CSS animations are hardware-accelerated</li>
                  </ul>
                </div>
              </div>

              {/* CSS Animation Classes */}
              <div>
                <Label className="text-sm font-medium mb-3 block">CSS Animation Classes</Label>
                <div className="bg-muted/20 p-4 rounded-lg">
                  <pre className="text-xs text-muted-foreground font-mono">
{`.animate-shimmer-slow  // 3s infinite loop for active state
.animate-shimmer-fast  // 1.5s single animation for hover

@keyframes shimmer {
  0%   { transform: translateX(-100%); opacity: 0; }
  50%  { opacity: 1; }
  100% { transform: translateX(100%); opacity: 0; }
}`}
                  </pre>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Avatar */}
          <div>
            <h4 className="mb-4">Avatars</h4>
            <div className="flex items-center gap-4">
              <Avatar className="h-8 w-8">
                <AvatarFallback>SM</AvatarFallback>
              </Avatar>
              <Avatar>
                <AvatarFallback>MD</AvatarFallback>
              </Avatar>
              <Avatar className="h-12 w-12">
                <AvatarFallback>LG</AvatarFallback>
              </Avatar>
              <Avatar className="h-16 w-16">
                <AvatarFallback>XL</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Spacing */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle>Spacing Scale</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {spacingScale.map((space) => (
              <div key={space.name} className="flex items-center gap-6">
                <div className="w-8 text-sm font-mono">{space.name}</div>
                <div className={`${space.class} bg-primary rounded`}></div>
                <div className="text-sm text-muted-foreground">{space.value}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Icons */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle>Icon Library</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-8 md:grid-cols-12 lg:grid-cols-16 gap-4">
            {iconSet.map((Icon, index) => (
              <div key={index} className="flex flex-col items-center gap-2 p-2 rounded hover:bg-white/20 dark:hover:bg-white/5 transition-all duration-300">
                <Icon className="h-5 w-5" />
                <span className="text-xs text-muted-foreground">{Icon.name}</span>
              </div>
            ))}
          </div>
          <p className="text-sm text-muted-foreground mt-4">
            Icons from Lucide React - consistent stroke width and style
          </p>
        </CardContent>
      </Card>

      {/* Design Principles */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle>Design Principles</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="mb-2">Consistency</h4>
              <p className="text-sm text-muted-foreground">
                Use consistent spacing, typography, and component patterns throughout the application.
              </p>
            </div>
            
            <div>
              <h4 className="mb-2">Hierarchy</h4>
              <p className="text-sm text-muted-foreground">
                Clear visual hierarchy using typography scales, spacing, and color contrast.
              </p>
            </div>
            
            <div>
              <h4 className="mb-2">Accessibility</h4>
              <p className="text-sm text-muted-foreground">
                WCAG compliant color contrasts and keyboard navigation support.
              </p>
            </div>
            
            <div>
              <h4 className="mb-2">Responsive</h4>
              <p className="text-sm text-muted-foreground">
                Mobile-first design that scales gracefully across all device sizes.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Usage Guidelines */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle>Usage Guidelines</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="mb-2">Button Usage</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Use primary buttons for main actions (max 1 per section)</li>
              <li>• Use secondary buttons for alternative actions</li>
              <li>• Use ghost buttons for less important actions</li>
              <li>• Use destructive variant only for delete/remove actions</li>
            </ul>
          </div>
          
          <Separator />
          
          <div>
            <h4 className="mb-2">Color Usage</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Use green badges/colors for positive states (Active, Success)</li>
              <li>• Use blue badges/colors for informational states (Lead, Info)</li>
              <li>• Use yellow badges/colors for warning states (Prospect, Pending)</li>
              <li>• Use red badges/colors for negative states (Error, Destructive)</li>
            </ul>
          </div>

          <Separator />
          
          <div>
            <h4 className="mb-2">Typography</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Base font size: 14px for optimal readability</li>
              <li>• Use font-medium (500) for headings and labels</li>
              <li>• Use font-normal (400) for body text</li>
              <li>• Maintain consistent line height of 1.5</li>
            </ul>
          </div>

          <Separator />
          
          <div>
            <h4 className="mb-2">Shimmer Menu Items</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Use for primary navigation elements in sidebars</li>
              <li>• Active state indicates current page with continuous shimmer</li>
              <li>• Hover shimmer provides interactive feedback</li>
              <li>• Combine with glass/blur effects for premium Apple aesthetic</li>
              <li>• Ensure sufficient color contrast for accessibility</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}