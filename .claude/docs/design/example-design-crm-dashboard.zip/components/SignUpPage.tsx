import { useState } from "react"
import { Button } from "./ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Separator } from "./ui/separator"
import { Checkbox } from "./ui/checkbox"
import { ArrowLeft, Eye, EyeOff } from "lucide-react"
import { GoogleLogo, AppleLogo } from "./BrandLogos"

interface SignUpPageProps {
  onSwitchToSignIn: () => void
  onBack: () => void
}

export function SignUpPage({ onSwitchToSignIn, onBack }: SignUpPageProps) {
  const [showPassword, setShowPassword] = useState(false)
  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [acceptedTerms, setAcceptedTerms] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const isFormValid = firstName && lastName && email && password && acceptedTerms

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!isFormValid) return

    setIsLoading(true)
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      // Here you would integrate with Clerk
      console.log("Sign up:", { firstName, lastName, email, password })
    }, 2000)
  }

  return (
    <div style={{
      width: '100%',
      maxWidth: '400px',
      display: 'flex',
      flexDirection: 'column',
      gap: '24px'
    }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: '16px',
        marginBottom: '8px'
      }}>
        <Button
          onClick={onBack}
          style={{
            backgroundColor: 'var(--secondary)',
            color: 'var(--secondary-foreground)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius)',
            padding: '8px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <ArrowLeft style={{ width: '16px', height: '16px' }} />
        </Button>
        <h1 style={{
          fontSize: 'var(--text-h2)',
          fontWeight: 'var(--font-weight-bold)',
          color: 'var(--foreground)',
          margin: 0
        }}>
          Sign Up
        </h1>
      </div>

      {/* Main Card */}
      <Card style={{
        backgroundColor: 'var(--card)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius-card)',
        boxShadow: 'var(--elevation-sm)'
      }}>
        <CardHeader style={{ paddingBottom: '16px' }}>
          <CardTitle style={{
            fontSize: 'var(--text-h3)',
            fontWeight: 'var(--font-weight-semibold)',
            color: 'var(--card-foreground)',
            margin: 0,
            textAlign: 'center'
          }}>
            Create your account
          </CardTitle>
          <p style={{
            fontSize: 'var(--text-base)',
            color: 'var(--muted-foreground)',
            margin: '8px 0 0 0',
            textAlign: 'center'
          }}>
            Get started with your free account
          </p>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={handleSubmit} style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '20px'
          }}>
            {/* Social Sign Up */}
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '12px'
            }}>
              <Button
                type="button"
                style={{
                  backgroundColor: 'var(--secondary)',
                  color: 'var(--secondary-foreground)',
                  border: '1px solid var(--border)',
                  borderRadius: 'var(--radius-button)',
                  padding: '12px 16px',
                  fontSize: 'var(--text-base)',
                  fontWeight: 'var(--font-weight-medium)',
                  cursor: 'pointer',
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '12px',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--muted)'
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--secondary)'
                }}
              >
                <GoogleLogo width={20} height={20} />
                Continue with Google
              </Button>
              
              <Button
                type="button"
                style={{
                  backgroundColor: 'var(--secondary)',
                  color: 'var(--secondary-foreground)',
                  border: '1px solid var(--border)',
                  borderRadius: 'var(--radius-button)',
                  padding: '12px 16px',
                  fontSize: 'var(--text-base)',
                  fontWeight: 'var(--font-weight-medium)',
                  cursor: 'pointer',
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '12px',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--muted)'
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--secondary)'
                }}
              >
                <AppleLogo width={20} height={20} />
                Continue with Apple
              </Button>
            </div>

            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '16px'
            }}>
              <Separator style={{ flex: 1 }} />
              <span style={{
                fontSize: 'var(--text-label)',
                color: 'var(--muted-foreground)',
                fontWeight: 'var(--font-weight-medium)'
              }}>
                or
              </span>
              <Separator style={{ flex: 1 }} />
            </div>

            {/* Name Fields */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '12px'
            }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <Label htmlFor="firstName" style={{
                  fontSize: 'var(--text-label)',
                  fontWeight: 'var(--font-weight-medium)',
                  color: 'var(--foreground)'
                }}>
                  First name
                </Label>
                <Input
                  id="firstName"
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder="John"
                  required
                  style={{
                    backgroundColor: 'var(--input-background)',
                    border: '1px solid var(--border)',
                    borderRadius: 'var(--radius)',
                    padding: '12px 16px',
                    fontSize: 'var(--text-base)',
                    color: 'var(--foreground)'
                  }}
                />
              </div>
              
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <Label htmlFor="lastName" style={{
                  fontSize: 'var(--text-label)',
                  fontWeight: 'var(--font-weight-medium)',
                  color: 'var(--foreground)'
                }}>
                  Last name
                </Label>
                <Input
                  id="lastName"
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder="Doe"
                  required
                  style={{
                    backgroundColor: 'var(--input-background)',
                    border: '1px solid var(--border)',
                    borderRadius: 'var(--radius)',
                    padding: '12px 16px',
                    fontSize: 'var(--text-base)',
                    color: 'var(--foreground)'
                  }}
                />
              </div>
            </div>

            {/* Email Field */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <Label htmlFor="email" style={{
                fontSize: 'var(--text-label)',
                fontWeight: 'var(--font-weight-medium)',
                color: 'var(--foreground)'
              }}>
                Email address
              </Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="john.doe@example.com"
                required
                style={{
                  backgroundColor: 'var(--input-background)',
                  border: '1px solid var(--border)',
                  borderRadius: 'var(--radius)',
                  padding: '12px 16px',
                  fontSize: 'var(--text-base)',
                  color: 'var(--foreground)'
                }}
              />
            </div>

            {/* Password Field */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <Label htmlFor="password" style={{
                fontSize: 'var(--text-label)',
                fontWeight: 'var(--font-weight-medium)',
                color: 'var(--foreground)'
              }}>
                Password
              </Label>
              <div style={{ position: 'relative' }}>
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Create a strong password"
                  required
                  style={{
                    backgroundColor: 'var(--input-background)',
                    border: '1px solid var(--border)',
                    borderRadius: 'var(--radius)',
                    padding: '12px 16px',
                    paddingRight: '48px',
                    fontSize: 'var(--text-base)',
                    color: 'var(--foreground)',
                    width: '100%'
                  }}
                />
                <Button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  style={{
                    position: 'absolute',
                    right: '12px',
                    top: '50%',
                    transform: 'translateY(-50%)',
                    backgroundColor: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    padding: '4px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  {showPassword ? (
                    <EyeOff style={{ width: '16px', height: '16px', color: 'var(--muted-foreground)' }} />
                  ) : (
                    <Eye style={{ width: '16px', height: '16px', color: 'var(--muted-foreground)' }} />
                  )}
                </Button>
              </div>
              <p style={{
                fontSize: 'var(--text-label)',
                color: 'var(--muted-foreground)',
                margin: 0
              }}>
                Must be at least 8 characters long
              </p>
            </div>

            {/* Terms and Conditions */}
            <div style={{
              display: 'flex',
              alignItems: 'flex-start',
              gap: '12px',
              backgroundColor: 'var(--muted)',
              padding: '16px',
              borderRadius: 'var(--radius)',
              border: '1px solid var(--border)'
            }}>
              <Checkbox
                id="terms"
                checked={acceptedTerms}
                onCheckedChange={setAcceptedTerms}
                style={{
                  marginTop: '2px'
                }}
              />
              <Label htmlFor="terms" style={{
                fontSize: 'var(--text-label)',
                fontWeight: 'var(--font-weight-medium)',
                color: 'var(--foreground)',
                lineHeight: '1.4',
                cursor: 'pointer'
              }}>
                I agree to the{' '}
                <button
                  type="button"
                  style={{
                    backgroundColor: 'transparent',
                    border: 'none',
                    color: 'var(--primary)',
                    fontSize: 'var(--text-label)',
                    fontWeight: 'var(--font-weight-medium)',
                    cursor: 'pointer',
                    textDecoration: 'underline'
                  }}
                >
                  Terms of Service
                </button>
                {' '}and{' '}
                <button
                  type="button"
                  style={{
                    backgroundColor: 'transparent',
                    border: 'none',
                    color: 'var(--primary)',
                    fontSize: 'var(--text-label)',
                    fontWeight: 'var(--font-weight-medium)',
                    cursor: 'pointer',
                    textDecoration: 'underline'
                  }}
                >
                  Privacy Policy
                </button>
              </Label>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={isLoading || !isFormValid}
              style={{
                backgroundColor: isLoading || !isFormValid ? 'var(--muted)' : 'var(--primary)',
                color: isLoading || !isFormValid ? 'var(--muted-foreground)' : 'var(--primary-foreground)',
                border: 'none',
                borderRadius: 'var(--radius-button)',
                padding: '16px 24px',
                fontSize: 'var(--text-base)',
                fontWeight: 'var(--font-weight-medium)',
                cursor: isLoading || !isFormValid ? 'not-allowed' : 'pointer',
                width: '100%',
                transition: 'all 0.2s ease'
              }}
            >
              {isLoading ? 'Creating account...' : 'Create Account'}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Sign In Link */}
      <div style={{
        textAlign: 'center',
        backgroundColor: 'var(--card)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius)',
        padding: '16px'
      }}>
        <span style={{
          fontSize: 'var(--text-base)',
          color: 'var(--muted-foreground)'
        }}>
          Already have an account?{' '}
        </span>
        <button
          onClick={onSwitchToSignIn}
          style={{
            backgroundColor: 'transparent',
            border: 'none',
            color: 'var(--primary)',
            fontSize: 'var(--text-base)',
            fontWeight: 'var(--font-weight-medium)',
            cursor: 'pointer',
            textDecoration: 'underline'
          }}
        >
          Sign in
        </button>
      </div>
    </div>
  )
}