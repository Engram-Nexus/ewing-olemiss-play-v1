import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Textarea } from "./ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar"
import { Separator } from "./ui/separator"
import { Camera, Save } from "lucide-react"

export function ProfileSettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2>Profile Settings</h2>
        <p className="text-muted-foreground">
          Manage your personal information and account details
        </p>
      </div>

      {/* Profile Picture */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle>Profile Picture</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-6">
            <Avatar className="h-20 w-20 ring-2 ring-white/20">
              <AvatarImage src="" />
              <AvatarFallback className="text-lg bg-gradient-to-br from-blue-400 to-purple-500 text-white">JD</AvatarFallback>
            </Avatar>
            <div className="space-y-2">
              <Button variant="outline" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl hover:scale-105 transition-all duration-300">
                <Camera className="h-4 w-4 mr-2" />
                Change Photo
              </Button>
              <p className="text-sm text-muted-foreground">
                JPG, PNG or GIF. Max size 2MB.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Personal Information */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle>Personal Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name</Label>
              <Input id="firstName" defaultValue="John" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name</Label>
              <Input id="lastName" defaultValue="Doe" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50" />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email Address</Label>
            <Input id="email" type="email" defaultValue="john.doe@example.com" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Phone Number</Label>
            <Input id="phone" defaultValue="+1 (555) 123-4567" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="title">Job Title</Label>
            <Input id="title" defaultValue="Sales Manager" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio">Bio</Label>
            <Textarea 
              id="bio" 
              placeholder="Tell us about yourself..."
              defaultValue="Experienced sales professional with a passion for building client relationships."
              className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          </div>
        </CardContent>
      </Card>

      {/* Company Information */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle>Company Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="company">Company Name</Label>
            <Input id="company" defaultValue="CRM Solutions Inc." className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="department">Department</Label>
              <Input id="department" defaultValue="Sales" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="location">Office Location</Label>
              <Input id="location" defaultValue="New York, NY" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button className="bg-primary text-primary-foreground rounded-xl hover:scale-105 transition-all duration-300 px-6">
          <Save className="h-4 w-4 mr-2" />
          Save Changes
        </Button>
      </div>
    </div>
  )
}