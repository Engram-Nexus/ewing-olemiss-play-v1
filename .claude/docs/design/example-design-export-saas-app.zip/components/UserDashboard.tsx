import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  LogOut, 
  Settings, 
  Edit3, 
  Calendar, 
  TrendingUp, 
  Clock, 
  FileText,
  Users,
  Star,
  Gift,
  Camera,
  Bell,
  Palette,
  Shield
} from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { User } from '../types/User';

interface UserDashboardProps {
  user: User;
  onLogout: () => void;
}

export function UserDashboard({ user, onLogout }: UserDashboardProps) {
  const [notifications, setNotifications] = useState(user.preferences.notifications);
  const [publicProfile, setPublicProfile] = useState(user.preferences.publicProfile);

  const formatJoinDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getProductivityLevel = (score: number) => {
    if (score >= 80) return { level: 'Legendary', color: 'text-purple-600', emoji: '🏆' };
    if (score >= 60) return { level: 'Expert', color: 'text-blue-600', emoji: '⭐' };
    if (score >= 40) return { level: 'Growing', color: 'text-green-600', emoji: '🌱' };
    return { level: 'Getting Started', color: 'text-yellow-600', emoji: '🚀' };
  };

  const productivity = getProductivityLevel(user.stats.productivity);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-yellow-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", delay: 0.2 }}
                className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center"
              >
                <Edit3 className="w-5 h-5 text-white" />
              </motion.div>
              <h1 className="text-xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Blinklist
              </h1>
            </div>
            <Button
              variant="ghost"
              onClick={onLogout}
              className="text-gray-600 hover:text-gray-800"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Welcome Section */}
          <Card className="mb-8 overflow-hidden">
            <div className={`h-24 bg-gradient-to-r ${user.personality.color}`}></div>
            <CardContent className="relative pt-0 pb-6">
              <div className="flex items-start space-x-4 -mt-8">
                <Avatar className="w-16 h-16 border-4 border-white shadow-lg">
                  <AvatarImage src={user.avatar} alt={user.displayName} />
                  <AvatarFallback className="bg-gradient-to-r from-purple-400 to-pink-400 text-white">
                    {user.displayName.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 pt-2">
                  <div className="flex items-center space-x-3 mb-2">
                    <h2 className="text-2xl">{user.displayName}</h2>
                    <Badge className={`bg-gradient-to-r ${user.personality.color} text-white border-0`}>
                      {user.personality.emoji} {user.personality.trait}
                    </Badge>
                  </div>
                  <p className="text-gray-600 mb-1">@{user.username}</p>
                  <p className="text-sm text-gray-500 italic">"{user.personality.description}"</p>
                </div>
                <div className="text-right pt-2">
                  <p className="text-sm text-gray-500">Member since</p>
                  <p className="text-sm">{formatJoinDate(user.joinDate)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card>
                <CardContent className="p-6 text-center">
                  <FileText className="w-8 h-8 mx-auto mb-3 text-blue-500" />
                  <h3 className="text-2xl mb-1">{user.stats.notesCreated}</h3>
                  <p className="text-sm text-gray-600">Notes Created</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card>
                <CardContent className="p-6 text-center">
                  <Calendar className="w-8 h-8 mx-auto mb-3 text-green-500" />
                  <h3 className="text-2xl mb-1">{user.stats.daysActive}</h3>
                  <p className="text-sm text-gray-600">Days Active</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card>
                <CardContent className="p-6 text-center">
                  <Clock className="w-8 h-8 mx-auto mb-3 text-purple-500" />
                  <h3 className="text-lg mb-1 capitalize">{user.stats.favoriteTime}</h3>
                  <p className="text-sm text-gray-600">Peak Creativity</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex items-center justify-center mb-3">
                    <TrendingUp className="w-6 h-6 mr-2 text-orange-500" />
                    <span className="text-2xl">{productivity.emoji}</span>
                  </div>
                  <h3 className={`text-lg mb-1 ${productivity.color}`}>{productivity.level}</h3>
                  <p className="text-sm text-gray-600">Productivity Level</p>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Tabbed Content */}
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="preferences">Preferences</TabsTrigger>
              <TabsTrigger value="achievements">Achievements</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Star className="w-5 h-5 mr-2 text-yellow-500" />
                      Quick Actions
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button className="w-full justify-start" variant="ghost">
                      <Edit3 className="w-4 h-4 mr-2" />
                      Create New Note
                    </Button>
                    <Button className="w-full justify-start" variant="ghost">
                      <FileText className="w-4 h-4 mr-2" />
                      Browse Templates
                    </Button>
                    <Button className="w-full justify-start" variant="ghost">
                      <Users className="w-4 h-4 mr-2" />
                      Join Community
                    </Button>
                    <Button className="w-full justify-start" variant="ghost">
                      <Gift className="w-4 h-4 mr-2" />
                      Explore Features
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <TrendingUp className="w-5 h-5 mr-2 text-green-500" />
                      Your Creative Journey
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Notes this week</span>
                        <Badge variant="secondary">+12</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Collaboration invites</span>
                        <Badge variant="secondary">3 pending</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Streak bonus</span>
                        <Badge className="bg-orange-100 text-orange-800">🔥 7 days</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="preferences" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Settings className="w-5 h-5 mr-2" />
                      Account Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Bell className="w-4 h-4 text-gray-600" />
                        <span>Push Notifications</span>
                      </div>
                      <Switch
                        checked={notifications}
                        onCheckedChange={setNotifications}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Shield className="w-4 h-4 text-gray-600" />
                        <span>Public Profile</span>
                      </div>
                      <Switch
                        checked={publicProfile}
                        onCheckedChange={setPublicProfile}
                      />
                    </div>
                    <div className="pt-4 border-t">
                      <Button variant="outline" className="w-full">
                        <Camera className="w-4 h-4 mr-2" />
                        Change Avatar
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Palette className="w-5 h-5 mr-2" />
                      Personality & Style
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-4 rounded-lg bg-gray-50">
                        <div className="flex items-center space-x-3 mb-2">
                          <div className={`w-8 h-8 rounded-full bg-gradient-to-r ${user.personality.color} flex items-center justify-center`}>
                            {user.personality.emoji}
                          </div>
                          <h4>{user.personality.trait}</h4>
                        </div>
                        <p className="text-sm text-gray-600 italic">"{user.personality.description}"</p>
                      </div>
                      <Button variant="outline" className="w-full">
                        Retake Personality Quiz
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="achievements" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  { title: "First Note", emoji: "📝", description: "Created your first note!", unlocked: true },
                  { title: "Week Warrior", emoji: "⚡", description: "Active for 7 consecutive days", unlocked: user.stats.daysActive >= 7 },
                  { title: "Note Master", emoji: "🎯", description: "Created 50+ notes", unlocked: user.stats.notesCreated >= 50 },
                  { title: "Early Bird", emoji: "🐦", description: "Most active in the morning", unlocked: user.stats.favoriteTime === 'morning' },
                  { title: "Night Owl", emoji: "🦉", description: "Most active late at night", unlocked: user.stats.favoriteTime === 'late night' },
                  { title: "Community Member", emoji: "👥", description: "Joined the Blinklist community", unlocked: false },
                ].map((achievement, index) => (
                  <motion.div
                    key={achievement.title}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className={achievement.unlocked ? 'border-green-200 bg-green-50' : 'border-gray-200 bg-gray-50'}>
                      <CardContent className="p-4 text-center">
                        <div className={`text-3xl mb-2 ${achievement.unlocked ? '' : 'grayscale'}`}>
                          {achievement.emoji}
                        </div>
                        <h4 className={`mb-1 ${achievement.unlocked ? 'text-green-800' : 'text-gray-500'}`}>
                          {achievement.title}
                        </h4>
                        <p className={`text-xs ${achievement.unlocked ? 'text-green-600' : 'text-gray-400'}`}>
                          {achievement.description}
                        </p>
                        {achievement.unlocked && (
                          <Badge className="mt-2 bg-green-100 text-green-800">
                            Unlocked!
                          </Badge>
                        )}
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}