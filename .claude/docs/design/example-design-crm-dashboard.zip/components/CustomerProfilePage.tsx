import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Badge } from "./ui/badge"
import { Button } from "./ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { Separator } from "./ui/separator"
import {
  ArrowLeft,
  Mail,
  Phone,
  MapPin,
  Building,
  Calendar,
  DollarSign,
  Edit,
  MessageSquare,
  FileText,
  Clock,
  TrendingUp,
  User,
  Plus
} from "lucide-react"
import { Progress } from "./ui/progress"

// Mock customer data - in a real app this would come from props or API
const customerData = {
  1: {
    id: 1,
    name: "Alice Johnson",
    email: "alice@example.com",
    phone: "+1 (555) 123-4567",
    company: "Tech Corp",
    status: "Active",
    value: "$12,500",
    lastContact: "2024-01-15",
    location: "New York, NY",
    industry: "Technology",
    notes: "Key decision maker for technology solutions",
    joinDate: "2023-03-15",
    totalDeals: 3,
    wonDeals: 2,
    totalValue: "$45,200",
    nextMeeting: "2024-01-25"
  },
  2: {
    id: 2,
    name: "Bob Smith",
    email: "bob@company.com",
    phone: "+1 (555) 987-6543",
    company: "Design Studio",
    status: "Lead",
    value: "$8,200",
    lastContact: "2024-01-10",
    location: "San Francisco, CA",
    industry: "Design",
    notes: "Interested in our premium package",
    joinDate: "2023-11-20",
    totalDeals: 1,
    wonDeals: 0,
    totalValue: "$8,200",
    nextMeeting: "2024-01-22"
  }
}

const activities = [
  {
    id: 1,
    type: "email",
    title: "Sent proposal for Q1 services",
    description: "Comprehensive proposal including timeline and pricing",
    date: "2024-01-15",
    time: "2:30 PM",
    status: "completed"
  },
  {
    id: 2,
    type: "call",
    title: "Follow-up call scheduled",
    description: "Discussed requirements and next steps",
    date: "2024-01-12",
    time: "10:00 AM",
    status: "completed"
  },
  {
    id: 3,
    type: "meeting",
    title: "Product demo completed",
    description: "Demonstrated key features and answered questions",
    date: "2024-01-08",
    time: "3:00 PM",
    status: "completed"
  },
  {
    id: 4,
    type: "email",
    title: "Initial contact email",
    description: "Welcome email with company information",
    date: "2024-01-05",
    time: "9:15 AM",
    status: "completed"
  }
]

const deals = [
  {
    id: 1,
    title: "Q1 Technology Upgrade",
    value: "$15,000",
    stage: "Proposal",
    probability: 75,
    expectedClose: "2024-02-15",
    status: "active"
  },
  {
    id: 2,
    title: "Annual Software License",
    value: "$8,500",
    stage: "Negotiation",
    probability: 90,
    expectedClose: "2024-01-30",
    status: "active"
  },
  {
    id: 3,
    title: "Initial Setup Package",
    value: "$12,500",
    stage: "Closed Won",
    probability: 100,
    expectedClose: "2023-12-20",
    status: "won"
  }
]

interface CustomerProfilePageProps {
  customerId: number
  onBack: () => void
}

export function CustomerProfilePage({ customerId, onBack }: CustomerProfilePageProps) {
  const [activeTab, setActiveTab] = useState("overview")
  
  const customer = customerData[customerId as keyof typeof customerData]
  
  if (!customer) {
    return (
      <div className="space-y-6">
        <div className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl p-6 shadow-lg shadow-black/5 rounded-xl border border-white/20">
          <div className="flex items-center gap-4 mb-6">
            <Button variant="ghost" size="sm" onClick={onBack} className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md rounded-xl">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Customers
            </Button>
          </div>
          <div className="text-center">
            <h2>Customer not found</h2>
            <p className="text-muted-foreground">The requested customer could not be found.</p>
          </div>
        </div>
      </div>
    )
  }

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase()
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400 border-0"
      case "Lead":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400 border-0"
      case "Prospect":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400 border-0"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400 border-0"
    }
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "email":
        return Mail
      case "call":
        return Phone
      case "meeting":
        return Calendar
      default:
        return MessageSquare
    }
  }

  const getStageColor = (stage: string) => {
    switch (stage) {
      case "Closed Won":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400 border-0"
      case "Proposal":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400 border-0"
      case "Negotiation":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400 border-0"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400 border-0"
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl p-6 shadow-lg shadow-black/5 rounded-xl border border-white/20">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="sm" onClick={onBack} className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md rounded-xl hover:scale-105 transition-all duration-300">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Customers
          </Button>
        </div>

        {/* Customer Header */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="flex items-center gap-6">
            <Avatar className="h-24 w-24 ring-4 ring-white/30">
              <AvatarImage src="" />
              <AvatarFallback className="bg-gradient-to-br from-blue-400 to-purple-500 text-white text-2xl font-semibold">
                {getInitials(customer.name)}
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-3xl font-semibold text-foreground mb-2">{customer.name}</h1>
              <div className="flex items-center gap-3 mb-3">
                <Building className="h-5 w-5 text-muted-foreground" />
                <span className="text-lg text-muted-foreground">{customer.company}</span>
              </div>
              <div className="flex items-center gap-4">
                <Badge className={getStatusColor(customer.status)}>
                  {customer.status}
                </Badge>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  <span>{customer.location}</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3">
            <Button className="bg-primary text-primary-foreground border-primary/20 rounded-xl hover:scale-105 transition-all duration-300">
              <Mail className="h-4 w-4 mr-2" />
              Send Email
            </Button>
            <Button className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl hover:scale-105 transition-all duration-300">
              <Phone className="h-4 w-4 mr-2" />
              Call
            </Button>
            <Button className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl hover:scale-105 transition-all duration-300">
              <Edit className="h-4 w-4 mr-2" />
              Edit
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <div className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl p-2 shadow-lg shadow-black/5 rounded-2xl w-fit border border-white/20">
          <TabsList className="bg-transparent border-0 space-x-1">
            <TabsTrigger 
              value="overview" 
              className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md rounded-xl px-6 py-3 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-300"
            >
              Overview
            </TabsTrigger>
            <TabsTrigger 
              value="activities"
              className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md rounded-xl px-6 py-3 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-300"
            >
              Activities
            </TabsTrigger>
            <TabsTrigger 
              value="deals"
              className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md rounded-xl px-6 py-3 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-300"
            >
              Deals
            </TabsTrigger>
            <TabsTrigger 
              value="documents"
              className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md rounded-xl px-6 py-3 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-300"
            >
              Documents
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Contact Information */}
            <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg font-semibold">
                  <User className="h-5 w-5 text-primary" />
                  Contact Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 rounded-xl bg-white/30 dark:bg-white/5">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <Mail className="h-4 w-4" />
                    Email
                  </div>
                  <p className="font-medium text-foreground">{customer.email}</p>
                </div>
                <div className="p-3 rounded-xl bg-white/30 dark:bg-white/5">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <Phone className="h-4 w-4" />
                    Phone
                  </div>
                  <p className="font-medium text-foreground">{customer.phone}</p>
                </div>
                <div className="p-3 rounded-xl bg-white/30 dark:bg-white/5">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <MapPin className="h-4 w-4" />
                    Location
                  </div>
                  <p className="font-medium text-foreground">{customer.location}</p>
                </div>
                <div className="p-3 rounded-xl bg-white/30 dark:bg-white/5">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                    <Building className="h-4 w-4" />
                    Industry
                  </div>
                  <p className="font-medium text-foreground">{customer.industry}</p>
                </div>
              </CardContent>
            </Card>

            {/* Key Metrics */}
            <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg font-semibold">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  Key Metrics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center p-3 rounded-xl bg-white/30 dark:bg-white/5">
                  <span className="text-muted-foreground">Total Value</span>
                  <span className="font-semibold text-foreground text-lg">{customer.totalValue}</span>
                </div>
                <div className="flex justify-between items-center p-3 rounded-xl bg-white/30 dark:bg-white/5">
                  <span className="text-muted-foreground">Total Deals</span>
                  <span className="font-semibold text-foreground text-lg">{customer.totalDeals}</span>
                </div>
                <div className="flex justify-between items-center p-3 rounded-xl bg-white/30 dark:bg-white/5">
                  <span className="text-muted-foreground">Won Deals</span>
                  <span className="font-semibold text-foreground text-lg">{customer.wonDeals}</span>
                </div>
                <div className="flex justify-between items-center p-3 rounded-xl bg-white/30 dark:bg-white/5">
                  <span className="text-muted-foreground">Win Rate</span>
                  <span className="font-semibold text-foreground text-lg">{Math.round((customer.wonDeals / customer.totalDeals) * 100)}%</span>
                </div>
                <Separator className="bg-white/20" />
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Customer Since</span>
                    <span className="text-sm font-medium">{customer.joinDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Last Contact</span>
                    <span className="text-sm font-medium">{customer.lastContact}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
              <CardHeader>
                <CardTitle className="text-lg font-semibold">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md w-full justify-start h-12 px-4 border-white/20 rounded-xl hover:scale-[1.02] transition-all duration-300">
                  <Calendar className="h-4 w-4 mr-3 text-purple-600" />
                  Schedule Meeting
                </Button>
                <Button className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md w-full justify-start h-12 px-4 border-white/20 rounded-xl hover:scale-[1.02] transition-all duration-300">
                  <FileText className="h-4 w-4 mr-3 text-blue-600" />
                  Create Proposal
                </Button>
                <Button className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md w-full justify-start h-12 px-4 border-white/20 rounded-xl hover:scale-[1.02] transition-all duration-300">
                  <Plus className="h-4 w-4 mr-3 text-green-600" />
                  Add Deal
                </Button>
                <Button className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md w-full justify-start h-12 px-4 border-white/20 rounded-xl hover:scale-[1.02] transition-all duration-300">
                  <MessageSquare className="h-4 w-4 mr-3 text-orange-600" />
                  Add Note
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Notes Section */}
          <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
            <CardHeader>
              <CardTitle className="text-lg font-semibold">Notes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="p-4 rounded-xl bg-white/30 dark:bg-white/5">
                <p className="text-foreground">{customer.notes}</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activities" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold">Recent Activities</h3>
            <Button className="bg-primary text-primary-foreground border-primary/20 rounded-xl hover:scale-105 transition-all duration-300">
              <Plus className="h-4 w-4 mr-2" />
              Log Activity
            </Button>
          </div>
          
          <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
            <CardContent className="p-0">
              <div className="space-y-0">
                {activities.map((activity, index) => {
                  const Icon = getActivityIcon(activity.type)
                  return (
                    <div key={activity.id}>
                      <div className="p-6 flex items-start gap-4 hover:bg-white/20 dark:hover:bg-white/5 transition-all duration-300">
                        <div className="p-3 rounded-xl bg-primary/10">
                          <Icon className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-semibold text-foreground">{activity.title}</h4>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Clock className="h-4 w-4" />
                              {activity.date} at {activity.time}
                            </div>
                          </div>
                          <p className="text-muted-foreground">{activity.description}</p>
                        </div>
                      </div>
                      {index < activities.length - 1 && <Separator className="bg-white/20" />}
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="deals" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold">Deals Pipeline</h3>
            <Button className="bg-primary text-primary-foreground border-primary/20 rounded-xl hover:scale-105 transition-all duration-300">
              <Plus className="h-4 w-4 mr-2" />
              Add Deal
            </Button>
          </div>

          <div className="grid gap-6">
            {deals.map((deal) => (
              <Card key={deal.id} className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl hover:scale-[1.01]">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-lg font-semibold text-foreground">{deal.title}</h4>
                    <Badge className={getStageColor(deal.stage)}>
                      {deal.stage}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="p-4 rounded-xl bg-white/30 dark:bg-white/5">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                        <DollarSign className="h-4 w-4" />
                        Value
                      </div>
                      <p className="text-xl font-semibold text-foreground">{deal.value}</p>
                    </div>
                    
                    <div className="p-4 rounded-xl bg-white/30 dark:bg-white/5">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                        <Calendar className="h-4 w-4" />
                        Expected Close
                      </div>
                      <p className="font-medium text-foreground">{deal.expectedClose}</p>
                    </div>
                    
                    <div className="p-4 rounded-xl bg-white/30 dark:bg-white/5">
                      <div className="text-sm text-muted-foreground mb-3">
                        Probability: {deal.probability}%
                      </div>
                      <Progress value={deal.probability} className="h-3 rounded-full" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="documents" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold">Documents</h3>
            <Button className="bg-primary text-primary-foreground border-primary/20 rounded-xl hover:scale-105 transition-all duration-300">
              <Plus className="h-4 w-4 mr-2" />
              Upload Document
            </Button>
          </div>
          
          <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
            <CardContent className="p-12 text-center">
              <div className="p-6 rounded-2xl bg-white/30 dark:bg-white/5 inline-block mb-6">
                <FileText className="h-16 w-16 mx-auto text-muted-foreground" />
              </div>
              <h4 className="text-xl font-semibold text-foreground mb-2">No documents uploaded</h4>
              <p className="text-muted-foreground">Upload contracts, proposals, and other documents related to this customer.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}