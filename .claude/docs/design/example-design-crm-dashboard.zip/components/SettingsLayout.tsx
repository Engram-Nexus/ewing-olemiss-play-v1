import { useState } from "react"
import { Card, CardContent } from "./ui/card"
import { Button } from "./ui/button"
import { ArrowLeft, User, Settings, Shield, Bell, Palette, HelpCircle } from "lucide-react"
import { cn } from "./ui/utils"

const settingsPages = [
  {
    id: "profile",
    title: "Profile",
    icon: User,
    description: "Manage your account information"
  },
  {
    id: "preferences",
    title: "Preferences",
    icon: Settings,
    description: "Customize your experience"
  },
  {
    id: "security",
    title: "Security",
    icon: Shield,
    description: "Password and security settings"
  },
  {
    id: "notifications",
    title: "Notifications",
    icon: Bell,
    description: "Email and push notification preferences"
  },
  {
    id: "style-guide",
    title: "Style Guide",
    icon: Palette,
    description: "Design system documentation"
  },
  {
    id: "help",
    title: "Help & Support",
    icon: HelpCircle,
    description: "Get help and contact support"
  }
]

interface SettingsLayoutProps {
  onBack: () => void
  children: React.ReactNode
  currentPage: string
  onPageChange: (page: string) => void
}

export function SettingsLayout({ onBack, children, currentPage, onPageChange }: SettingsLayoutProps) {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={onBack} className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md rounded-xl hover:scale-105 transition-all duration-300">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
        <h1>Settings</h1>
      </div>

      {/* Settings Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Settings Navigation */}
        <Card className="lg:col-span-1 bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5">
          <CardContent className="p-4">
            <nav className="space-y-2">
              {settingsPages.map((page) => (
                <Button
                  key={page.id}
                  variant={currentPage === page.id ? "default" : "ghost"}
                  className={cn(
                    "w-full justify-start gap-3 p-3 h-auto transition-all duration-300 rounded-xl",
                    currentPage === page.id 
                      ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" 
                      : "hover:bg-white/50 dark:hover:bg-white/10 text-foreground/80 hover:text-foreground hover:scale-[1.02]"
                  )}
                  onClick={() => onPageChange(page.id)}
                >
                  <page.icon className="h-4 w-4 shrink-0" />
                  <div className="text-left">
                    <div className="font-medium">{page.title}</div>
                    <div className="text-xs opacity-70">{page.description}</div>
                  </div>
                </Button>
              ))}
            </nav>
          </CardContent>
        </Card>

        {/* Settings Content */}
        <div className="lg:col-span-3">
          {children}
        </div>
      </div>
    </div>
  )
}