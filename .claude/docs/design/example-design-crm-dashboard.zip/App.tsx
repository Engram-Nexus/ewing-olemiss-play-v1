import { useState } from "react"
import { SignInPage } from "./components/SignInPage"
import { SignUpPage } from "./components/SignUpPage"
import { WelcomePage } from "./components/WelcomePage"

type AuthView = 'welcome' | 'signin' | 'signup'

export default function App() {
  const [currentView, setCurrentView] = useState<AuthView>('welcome')

  const renderCurrentView = () => {
    switch (currentView) {
      case 'signin':
        return <SignInPage onSwitchToSignUp={() => setCurrentView('signup')} onBack={() => setCurrentView('welcome')} />
      case 'signup':
        return <SignUpPage onSwitchToSignIn={() => setCurrentView('signin')} onBack={() => setCurrentView('welcome')} />
      default:
        return <WelcomePage onSignIn={() => setCurrentView('signin')} onSignUp={() => setCurrentView('signup')} />
    }
  }

  return (
    <div style={{
      minHeight: '100vh',
      backgroundColor: 'var(--background)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px'
    }}>
      {renderCurrentView()}
    </div>
  )
}