import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Eye, EyeOff, Sparkles, Mail, Lock, User as UserIcon, ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { User, PERSONALITY_TRAITS, UserPersonality } from '../types/User';

interface RegisterFormProps {
  onRegister: (user: User) => void;
  onSwitchToLogin: () => void;
}

export function RegisterForm({ onRegister, onSwitchToLogin }: RegisterFormProps) {
  const [step, setStep] = useState<'details' | 'personality'>('details');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [selectedPersonality, setSelectedPersonality] = useState<UserPersonality | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('personality');
  };

  const handlePersonalitySelect = (personality: UserPersonality) => {
    setSelectedPersonality(personality);
  };

  const handleFinalSubmit = async () => {
    if (!selectedPersonality) return;
    
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 2000));

    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      email,
      username,
      displayName: displayName || username,
      avatar: `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${username}`,
      personality: selectedPersonality,
      stats: {
        notesCreated: 0,
        daysActive: 0,
        favoriteTime: 'morning',
        productivity: 100
      },
      preferences: {
        theme: 'light',
        notifications: true,
        publicProfile: false
      },
      joinDate: new Date().toISOString()
    };

    onRegister(newUser);
    setIsLoading(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="backdrop-blur-sm bg-white/80 shadow-xl border-0">
        <CardHeader className="text-center space-y-4">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="mx-auto w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center"
          >
            <Sparkles className="w-8 h-8 text-white" />
          </motion.div>
          <div>
            <CardTitle className="text-2xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Join Blinklist
            </CardTitle>
            <p className="text-gray-600 mt-2">
              {step === 'details' 
                ? "Let's get you set up! 🎉" 
                : "What's your creative personality? 🎭"
              }
            </p>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          <AnimatePresence mode="wait">
            {step === 'details' ? (
              <motion.div
                key="details"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.3 }}
              >
                <form onSubmit={handleDetailsSubmit} className="space-y-4">
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      type="email"
                      placeholder="your-email@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10 border-gray-200 focus:border-purple-300"
                      required
                    />
                  </div>

                  <div className="relative">
                    <UserIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      type="text"
                      placeholder="username (unique identifier)"
                      value={username}
                      onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                      className="pl-10 border-gray-200 focus:border-purple-300"
                      required
                    />
                  </div>

                  <div className="relative">
                    <Sparkles className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      type="text"
                      placeholder="display name (how others see you)"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      className="pl-10 border-gray-200 focus:border-purple-300"
                    />
                  </div>

                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Create a strong password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 pr-10 border-gray-200 focus:border-purple-300"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
                  >
                    Next: Choose Your Personality! ✨
                  </Button>
                </form>
              </motion.div>
            ) : (
              <motion.div
                key="personality"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="space-y-4"
              >
                <Button
                  variant="ghost"
                  onClick={() => setStep('details')}
                  className="text-gray-600 hover:text-gray-800 p-0 h-auto"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to details
                </Button>

                <div className="grid gap-3">
                  {PERSONALITY_TRAITS.map((personality, index) => (
                    <motion.div
                      key={personality.trait}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <Card
                        className={`cursor-pointer transition-all duration-200 hover:shadow-md ${
                          selectedPersonality?.trait === personality.trait
                            ? 'ring-2 ring-purple-400 bg-purple-50'
                            : 'hover:bg-gray-50'
                        }`}
                        onClick={() => handlePersonalitySelect(personality)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center space-x-3">
                            <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${personality.color} flex items-center justify-center text-xl`}>
                              {personality.emoji}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center space-x-2">
                                <h3 className="font-medium">{personality.trait}</h3>
                                {selectedPersonality?.trait === personality.trait && (
                                  <Badge className="bg-purple-100 text-purple-800">Selected</Badge>
                                )}
                              </div>
                              <p className="text-sm text-gray-600 mt-1">{personality.description}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>

                {selectedPersonality && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <Button
                      onClick={handleFinalSubmit}
                      disabled={isLoading}
                      className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
                    >
                      {isLoading ? (
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                          className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full"
                        />
                      ) : (
                        "Create My Account! 🎉"
                      )}
                    </Button>
                  </motion.div>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          <div className="text-center">
            <Button
              variant="ghost"
              onClick={onSwitchToLogin}
              className="text-purple-600 hover:text-purple-700 hover:bg-purple-50"
            >
              Already have an account? Sign in! 👋
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}