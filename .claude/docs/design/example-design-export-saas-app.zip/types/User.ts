export interface User {
  id: string;
  email: string;
  username: string;
  displayName: string;
  avatar: string;
  personality: UserPersonality;
  stats: UserStats;
  preferences: UserPreferences;
  joinDate: string;
}

export interface UserPersonality {
  trait: string;
  emoji: string;
  description: string;
  color: string;
}

export interface UserStats {
  notesCreated: number;
  daysActive: number;
  favoriteTime: string;
  productivity: number;
}

export interface UserPreferences {
  theme: 'light' | 'dark' | 'auto';
  notifications: boolean;
  publicProfile: boolean;
}

export const PERSONALITY_TRAITS = [
  {
    trait: "The Midnight Owl",
    emoji: "🦉",
    description: "You do your best thinking when the world is asleep",
    color: "from-indigo-500 to-purple-600"
  },
  {
    trait: "The Coffee Wizard",
    emoji: "☕",
    description: "Powered by caffeine and endless curiosity",
    color: "from-amber-500 to-orange-600"
  },
  {
    trait: "The Idea Collector",
    emoji: "💡",
    description: "You see inspiration everywhere you look",
    color: "from-yellow-400 to-yellow-600"
  },
  {
    trait: "The Organization Ninja",
    emoji: "🥷",
    description: "Chaos fears you and your color-coded systems",
    color: "from-green-500 to-emerald-600"
  },
  {
    trait: "The Creative Tornado",
    emoji: "🌪️",
    description: "Your mind moves faster than you can type",
    color: "from-pink-500 to-rose-600"
  },
  {
    trait: "The Knowledge Sponge",
    emoji: "🧽",
    description: "Absorbing information is your superpower",
    color: "from-blue-500 to-cyan-600"
  },
  {
    trait: "The Digital Minimalist",
    emoji: "🌱",
    description: "Less is more, and you've mastered the art",
    color: "from-teal-500 to-green-600"
  },
  {
    trait: "The Emoji Enthusiast",
    emoji: "🎨",
    description: "Why use words when pictures say it all?",
    color: "from-purple-500 to-pink-600"
  }
];