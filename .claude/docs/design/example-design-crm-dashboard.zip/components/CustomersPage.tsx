import { useState } from "react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table"
import { Input } from "./ui/input"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { 
  Search, 
  Plus, 
  Mail, 
  Phone, 
  MoreHorizontal, 
  Filter,
  Users,
  UserPlus,
  Calendar,
  DollarSign,
  Edit,
  Trash,
  Eye
} from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select"
import { Checkbox } from "./ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog"
import { Label } from "./ui/label"
import { Textarea } from "./ui/textarea"

const customers = [
  {
    id: 1,
    name: "Alice Johnson",
    email: "alice@example.com",
    phone: "+1 (555) 123-4567",
    company: "Tech Corp",
    status: "Active",
    value: "$12,500",
    lastContact: "2024-01-15",
    location: "New York, NY",
    industry: "Technology",
    notes: "Key decision maker for technology solutions"
  },
  {
    id: 2,
    name: "Bob Smith",
    email: "bob@company.com",
    phone: "+1 (555) 987-6543",
    company: "Design Studio",
    status: "Lead",
    value: "$8,200",
    lastContact: "2024-01-10",
    location: "San Francisco, CA",
    industry: "Design",
    notes: "Interested in our premium package"
  },
  {
    id: 3,
    name: "Carol Davis",
    email: "carol@business.net",
    phone: "+1 (555) 456-7890",
    company: "Marketing Pro",
    status: "Active",
    value: "$25,800",
    lastContact: "2024-01-18",
    location: "Chicago, IL",
    industry: "Marketing",
    notes: "Long-term client, very satisfied"
  },
  {
    id: 4,
    name: "David Wilson",
    email: "david@startup.io",
    phone: "+1 (555) 321-0987",
    company: "Innovation Inc",
    status: "Prospect",
    value: "$5,500",
    lastContact: "2024-01-12",
    location: "Austin, TX",
    industry: "Technology",
    notes: "Potential for large contract"
  },
  {
    id: 5,
    name: "Emma Brown",
    email: "emma@enterprise.com",
    phone: "+1 (555) 654-3210",
    company: "Global Solutions",
    status: "Active",
    value: "$45,200",
    lastContact: "2024-01-20",
    location: "Boston, MA",
    industry: "Consulting",
    notes: "Enterprise client with multiple projects"
  },
  {
    id: 6,
    name: "Frank Miller",
    email: "frank@retail.com",
    phone: "+1 (555) 789-0123",
    company: "Retail Plus",
    status: "Lead",
    value: "$7,800",
    lastContact: "2024-01-08",
    location: "Miami, FL",
    industry: "Retail",
    notes: "Exploring integration options"
  }
]

const customerStats = [
  {
    title: "Total Customers",
    value: "2,463",
    change: "+12%",
    icon: Users,
    color: "text-blue-600",
    bgColor: "bg-blue-50",
    darkBgColor: "dark:bg-blue-900/20"
  },
  {
    title: "New This Month",
    value: "89",
    change: "+23%",
    icon: UserPlus,
    color: "text-green-600",
    bgColor: "bg-green-50",
    darkBgColor: "dark:bg-green-900/20"
  },
  {
    title: "Active Deals",
    value: "142",
    change: "+8%",
    icon: Calendar,
    color: "text-purple-600",
    bgColor: "bg-purple-50",
    darkBgColor: "dark:bg-purple-900/20"
  },
  {
    title: "Total Value",
    value: "$324,567",
    change: "+15%",
    icon: DollarSign,
    color: "text-orange-600",
    bgColor: "bg-orange-50",
    darkBgColor: "dark:bg-orange-900/20"
  }
]

interface CustomersPageProps {
  onCustomerClick: (customerId: number) => void
}

export function CustomersPage({ onCustomerClick }: CustomersPageProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedCustomers, setSelectedCustomers] = useState<number[]>([])
  const [selectedCustomer, setSelectedCustomer] = useState<typeof customers[0] | null>(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)

  const filteredCustomers = customers.filter(customer => {
    const matchesSearch = customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         customer.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         customer.email.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesStatus = statusFilter === "all" || customer.status.toLowerCase() === statusFilter.toLowerCase()
    
    return matchesSearch && matchesStatus
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400 border-0"
      case "Lead":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400 border-0"
      case "Prospect":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400 border-0"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400 border-0"
    }
  }

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase()
  }

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedCustomers(filteredCustomers.map(c => c.id))
    } else {
      setSelectedCustomers([])
    }
  }

  const handleSelectCustomer = (customerId: number, checked: boolean) => {
    if (checked) {
      setSelectedCustomers([...selectedCustomers, customerId])
    } else {
      setSelectedCustomers(selectedCustomers.filter(id => id !== customerId))
    }
  }

  const handleRowClick = (customer: typeof customers[0], event: React.MouseEvent) => {
    const target = event.target as HTMLElement
    if (target.closest('input[type="checkbox"]') || 
        target.closest('[role="button"]') || 
        target.closest('button')) {
      return
    }
    onCustomerClick(customer.id)
  }

  return (
    <div className="space-y-8">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {customerStats.map((stat) => (
          <Card key={stat.title} className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl hover:scale-[1.02]">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-xl ${stat.bgColor} ${stat.darkBgColor}`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
                <span className="text-sm font-medium text-green-600">{stat.change}</span>
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground mb-1">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.title}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Header and Controls */}
      <div className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl p-6 shadow-lg shadow-black/5 rounded-xl border border-white/20">
        <div className="flex flex-col lg:flex-row gap-6 items-start lg:items-center justify-between">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search customers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64 bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40 bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent className="bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-white/20">
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="lead">Lead</SelectItem>
                <SelectItem value="prospect">Prospect</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-3">
            {selectedCustomers.length > 0 && (
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">
                  {selectedCustomers.length} selected
                </span>
                <Button variant="outline" size="sm" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-lg">
                  <Mail className="h-4 w-4 mr-2" />
                  Email
                </Button>
                <Button variant="outline" size="sm" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-lg text-destructive">
                  <Trash className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </div>
            )}
            <Button onClick={() => setIsAddDialogOpen(true)} className="bg-primary text-primary-foreground border-primary/20 rounded-xl px-6 hover:scale-105 transition-all duration-300">
              <Plus className="h-4 w-4 mr-2" />
              Add Customer
            </Button>
          </div>
        </div>
      </div>

      {/* Customer Table */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-white/20 hover:bg-transparent">
                <TableHead className="w-12 pl-6">
                  <Checkbox
                    checked={selectedCustomers.length === filteredCustomers.length && filteredCustomers.length > 0}
                    onCheckedChange={handleSelectAll}
                    className="rounded-md focus:outline-none focus:ring-2 focus:ring-primary/50"
                  />
                </TableHead>
                <TableHead className="font-semibold">Customer</TableHead>
                <TableHead className="font-semibold">Company</TableHead>
                <TableHead className="font-semibold">Status</TableHead>
                <TableHead className="font-semibold">Value</TableHead>
                <TableHead className="font-semibold">Industry</TableHead>
                <TableHead className="font-semibold">Last Contact</TableHead>
                <TableHead className="w-12"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCustomers.map((customer) => (
                <TableRow 
                  key={customer.id}
                  className="cursor-pointer hover:bg-white/30 dark:hover:bg-white/5 transition-all duration-300 border-white/10"
                  onClick={(e) => handleRowClick(customer, e)}
                >
                  <TableCell className="pl-6" onClick={(e) => e.stopPropagation()}>
                    <Checkbox
                      checked={selectedCustomers.includes(customer.id)}
                      onCheckedChange={(checked) => handleSelectCustomer(customer.id, checked as boolean)}
                      className="rounded-md focus:outline-none focus:ring-2 focus:ring-primary/50"
                    />
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-10 w-10 ring-2 ring-white/20">
                        <AvatarImage src="" />
                        <AvatarFallback className="bg-gradient-to-br from-blue-400 to-purple-500 text-white font-medium">
                          {getInitials(customer.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium text-foreground">{customer.name}</div>
                        <div className="text-sm text-muted-foreground">{customer.email}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium text-foreground">{customer.company}</div>
                      <div className="text-sm text-muted-foreground">{customer.location}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(customer.status)}>
                      {customer.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-semibold text-foreground">{customer.value}</TableCell>
                  <TableCell className="text-muted-foreground">{customer.industry}</TableCell>
                  <TableCell className="text-muted-foreground">{customer.lastContact}</TableCell>
                  <TableCell onClick={(e) => e.stopPropagation()}>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-white/20 rounded-lg">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-white/20">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => onCustomerClick(customer.id)}>
                          <Eye className="h-4 w-4 mr-2" />
                          View Profile
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuSeparator className="bg-white/20" />
                        <DropdownMenuItem>
                          <Mail className="h-4 w-4 mr-2" />
                          Send Email
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Phone className="h-4 w-4 mr-2" />
                          Call
                        </DropdownMenuItem>
                        <DropdownMenuSeparator className="bg-white/20" />
                        <DropdownMenuItem className="text-red-600">
                          <Trash className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Add Customer Modal */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-white/20 shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold">Add New Customer</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Create a new customer record
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input id="name" placeholder="Customer name" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50 mt-1" />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" placeholder="customer@example.com" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50 mt-1" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="phone">Phone</Label>
                <Input id="phone" placeholder="+1 (555) 123-4567" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50 mt-1" />
              </div>
              <div>
                <Label htmlFor="company">Company</Label>
                <Input id="company" placeholder="Company name" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50 mt-1" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="location">Location</Label>
                <Input id="location" placeholder="City, State" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50 mt-1" />
              </div>
              <div>
                <Label htmlFor="industry">Industry</Label>
                <Input id="industry" placeholder="Technology, Healthcare, etc." className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50 mt-1" />
              </div>
            </div>
            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea id="notes" placeholder="Customer notes..." className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50 mt-1" />
            </div>
          </div>
          <DialogFooter className="gap-3">
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)} className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl">
              Cancel
            </Button>
            <Button onClick={() => setIsAddDialogOpen(false)} className="bg-primary text-primary-foreground rounded-xl hover:scale-105 transition-all duration-300">
              Add Customer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}