import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Badge } from "./ui/badge"
import { Button } from "./ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar"
import { 
  Users, 
  DollarSign, 
  Calendar, 
  TrendingUp, 
  Plus,
  Mail,
  Phone,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  BarChart3
} from "lucide-react"

const metrics = [
  {
    title: "Total Customers",
    value: "2,463",
    change: "+12%",
    trend: "up",
    icon: Users,
    chartColor: "var(--chart-1)"
  },
  {
    title: "Monthly Revenue",
    value: "$54,239",
    change: "+8%",
    trend: "up",
    icon: DollarSign,
    chartColor: "var(--chart-2)"
  },
  {
    title: "Active Deals",
    value: "142",
    change: "+23%",
    trend: "up",
    icon: Calendar,
    chartColor: "var(--chart-5)"
  },
  {
    title: "Conversion Rate",
    value: "68.2%",
    change: "-3%",
    trend: "down",
    icon: TrendingUp,
    chartColor: "var(--chart-3)"
  }
]

const recentActivities = [
  {
    id: 1,
    type: "new_customer",
    title: "New customer added",
    description: "Alice Johnson from Tech Corp",
    time: "2 minutes ago",
    icon: Users,
    chartColor: "var(--chart-1)"
  },
  {
    id: 2,
    type: "deal_closed",
    title: "Deal closed",
    description: "$15,000 contract with Design Studio",
    time: "1 hour ago",
    icon: DollarSign,
    chartColor: "var(--chart-2)"
  },
  {
    id: 3,
    type: "meeting_scheduled",
    title: "Meeting scheduled",
    description: "Product demo with Innovation Inc",
    time: "3 hours ago",
    icon: Calendar,
    chartColor: "var(--chart-5)"
  },
  {
    id: 4,
    type: "email_sent",
    title: "Email sent",
    description: "Follow-up email to Global Solutions",
    time: "5 hours ago",
    icon: Mail,
    chartColor: "var(--chart-3)"
  },
  {
    id: 5,
    type: "call_completed",
    title: "Call completed",
    description: "Discovery call with Retail Plus",
    time: "1 day ago",
    icon: Phone,
    chartColor: "var(--chart-4)"
  }
]

export function DashboardPage() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      {/* Welcome Section */}
      <div style={{
        backgroundColor: 'var(--card)',
        backdropFilter: 'blur(20px)',
        borderRadius: 'var(--radius-card)',
        padding: '32px',
        boxShadow: 'var(--elevation-sm)',
        border: '1px solid var(--border)',
        transition: 'all 0.3s ease'
      }}>
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '24px'
        }}>
          <div>
            <h1 style={{
              fontFamily: 'var(--font-family)',
              fontSize: 'var(--text-h1)',
              fontWeight: 'var(--font-weight-semibold)',
              color: 'var(--foreground)',
              margin: '0 0 8px 0'
            }}>
              Welcome back, John! 👋
            </h1>
            <p style={{
              fontFamily: 'var(--font-family)',
              fontSize: 'var(--text-base)',
              fontWeight: 'var(--font-weight-normal)',
              color: 'var(--muted-foreground)',
              margin: 0
            }}>
              Here's what's happening with your business today.
            </p>
          </div>
          <Button style={{
            backgroundColor: 'var(--primary)',
            color: 'var(--primary-foreground)',
            border: 'none',
            borderRadius: 'var(--radius-button)',
            fontFamily: 'var(--font-family)',
            fontSize: 'var(--text-base)',
            fontWeight: 'var(--font-weight-medium)',
            padding: '12px 24px',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            cursor: 'pointer',
            transition: 'all 0.3s ease',
            alignSelf: 'flex-start'
          }}>
            <Plus style={{ height: '20px', width: '20px' }} />
            Add Customer
          </Button>
        </div>
      </div>

      {/* Metrics Cards */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
        gap: '24px'
      }}>
        {metrics.map((metric) => (
          <Card key={metric.title} style={{
            backgroundColor: 'var(--card)',
            borderRadius: 'var(--radius-card)',
            border: '1px solid var(--border)',
            boxShadow: 'var(--elevation-sm)',
            transition: 'all 0.3s ease'
          }}>
            <CardContent style={{ padding: '24px' }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: '16px'
              }}>
                <div style={{
                  padding: '12px',
                  borderRadius: 'var(--radius)',
                  backgroundColor: 'var(--muted)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}>
                  <metric.icon style={{
                    height: '24px',
                    width: '24px',
                    color: metric.chartColor
                  }} />
                </div>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px'
                }}>
                  {metric.trend === "up" ? (
                    <ArrowUpRight style={{
                      height: '16px',
                      width: '16px',
                      color: 'var(--chart-2)'
                    }} />
                  ) : (
                    <ArrowDownRight style={{
                      height: '16px',
                      width: '16px',
                      color: 'var(--chart-4)'
                    }} />
                  )}
                  <span style={{
                    fontFamily: 'var(--font-family)',
                    fontSize: 'var(--text-label)',
                    fontWeight: 'var(--font-weight-medium)',
                    color: metric.trend === "up" ? 'var(--chart-2)' : 'var(--chart-4)'
                  }}>
                    {metric.change}
                  </span>
                </div>
              </div>
              <div>
                <p style={{
                  fontFamily: 'var(--font-family)',
                  fontSize: 'var(--text-h2)',
                  fontWeight: 'var(--font-weight-semibold)',
                  color: 'var(--foreground)',
                  margin: '0 0 4px 0'
                }}>
                  {metric.value}
                </p>
                <p style={{
                  fontFamily: 'var(--font-family)',
                  fontSize: 'var(--text-label)',
                  fontWeight: 'var(--font-weight-medium)',
                  color: 'var(--muted-foreground)',
                  margin: 0
                }}>
                  {metric.title}
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content Grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))',
        gap: '32px'
      }}>
        {/* Recent Activities */}
        <Card style={{
          backgroundColor: 'var(--card)',
          borderRadius: 'var(--radius-card)',
          border: '1px solid var(--border)',
          boxShadow: 'var(--elevation-sm)',
          transition: 'all 0.3s ease'
        }}>
          <CardHeader style={{ paddingBottom: '16px' }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}>
              <CardTitle style={{
                fontFamily: 'var(--font-family)',
                fontSize: 'var(--text-h3)',
                fontWeight: 'var(--font-weight-semibold)',
                color: 'var(--card-foreground)',
                margin: 0
              }}>
                Recent Activities
              </CardTitle>
              <Button style={{
                background: 'transparent',
                color: 'var(--primary)',
                border: 'none',
                borderRadius: 'var(--radius)',
                fontFamily: 'var(--font-family)',
                fontSize: 'var(--text-label)',
                fontWeight: 'var(--font-weight-medium)',
                padding: '8px 12px',
                cursor: 'pointer'
              }}>
                View All
              </Button>
            </div>
          </CardHeader>
          <CardContent style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {recentActivities.map((activity) => (
              <div key={activity.id} style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: '16px',
                padding: '12px',
                borderRadius: 'var(--radius)',
                transition: 'all 0.3s ease',
                cursor: 'pointer'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--muted)'
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent'
              }}>
                <div style={{
                  padding: '8px',
                  borderRadius: 'var(--radius)',
                  backgroundColor: 'var(--muted)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}>
                  <activity.icon style={{
                    height: '16px',
                    width: '16px',
                    color: activity.chartColor
                  }} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{
                    fontFamily: 'var(--font-family)',
                    fontSize: 'var(--text-base)',
                    fontWeight: 'var(--font-weight-medium)',
                    color: 'var(--foreground)',
                    margin: '0 0 4px 0'
                  }}>
                    {activity.title}
                  </p>
                  <p style={{
                    fontFamily: 'var(--font-family)',
                    fontSize: 'var(--text-label)',
                    fontWeight: 'var(--font-weight-normal)',
                    color: 'var(--muted-foreground)',
                    margin: '0 0 4px 0'
                  }}>
                    {activity.description}
                  </p>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px'
                  }}>
                    <Clock style={{
                      height: '12px',
                      width: '12px',
                      color: 'var(--muted-foreground)'
                    }} />
                    <span style={{
                      fontFamily: 'var(--font-family)',
                      fontSize: 'var(--text-label)',
                      fontWeight: 'var(--font-weight-normal)',
                      color: 'var(--muted-foreground)'
                    }}>
                      {activity.time}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card style={{
          backgroundColor: 'var(--card)',
          borderRadius: 'var(--radius-card)',
          border: '1px solid var(--border)',
          boxShadow: 'var(--elevation-sm)',
          transition: 'all 0.3s ease'
        }}>
          <CardHeader style={{ paddingBottom: '16px' }}>
            <CardTitle style={{
              fontFamily: 'var(--font-family)',
              fontSize: 'var(--text-h3)',
              fontWeight: 'var(--font-weight-semibold)',
              color: 'var(--card-foreground)',
              margin: 0
            }}>
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {[
              { icon: Users, title: "Add New Customer", desc: "Create a new customer record", color: "var(--chart-1)" },
              { icon: Calendar, title: "Schedule Meeting", desc: "Book a meeting with a customer", color: "var(--chart-5)" },
              { icon: Mail, title: "Send Campaign", desc: "Create and send email campaign", color: "var(--chart-3)" },
              { icon: BarChart3, title: "View Reports", desc: "Check performance analytics", color: "var(--chart-2)" }
            ].map((action, index) => (
              <Button key={index} style={{
                backgroundColor: 'var(--secondary)',
                color: 'var(--secondary-foreground)',
                border: '1px solid var(--border)',
                borderRadius: 'var(--radius)',
                fontFamily: 'var(--font-family)',
                fontSize: 'var(--text-base)',
                fontWeight: 'var(--font-weight-medium)',
                padding: '16px',
                height: '56px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'flex-start',
                gap: '12px',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                textAlign: 'left'
              }}>
                <action.icon style={{
                  height: '20px',
                  width: '20px',
                  color: action.color
                }} />
                <div>
                  <div style={{
                    fontFamily: 'var(--font-family)',
                    fontSize: 'var(--text-base)',
                    fontWeight: 'var(--font-weight-medium)',
                    color: 'var(--foreground)'
                  }}>
                    {action.title}
                  </div>
                  <div style={{
                    fontFamily: 'var(--font-family)',
                    fontSize: 'var(--text-label)',
                    fontWeight: 'var(--font-weight-normal)',
                    color: 'var(--muted-foreground)'
                  }}>
                    {action.desc}
                  </div>
                </div>
              </Button>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Top Customers */}
      <Card style={{
        backgroundColor: 'var(--card)',
        borderRadius: 'var(--radius-card)',
        border: '1px solid var(--border)',
        boxShadow: 'var(--elevation-sm)',
        transition: 'all 0.3s ease'
      }}>
        <CardHeader style={{ paddingBottom: '16px' }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between'
          }}>
            <CardTitle style={{
              fontFamily: 'var(--font-family)',
              fontSize: 'var(--text-h3)',
              fontWeight: 'var(--font-weight-semibold)',
              color: 'var(--card-foreground)',
              margin: 0
            }}>
              Top Customers
            </CardTitle>
            <Button style={{
              background: 'transparent',
              color: 'var(--primary)',
              border: 'none',
              borderRadius: 'var(--radius)',
              fontFamily: 'var(--font-family)',
              fontSize: 'var(--text-label)',
              fontWeight: 'var(--font-weight-medium)',
              padding: '8px 12px',
              cursor: 'pointer'
            }}>
              View All
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {[
              { name: "Alice Johnson", company: "Tech Corp", value: "$45,200", status: "Active" },
              { name: "Bob Smith", company: "Design Studio", value: "$32,100", status: "Active" },
              { name: "Carol Davis", company: "Marketing Pro", value: "$28,900", status: "Lead" },
              { name: "David Wilson", company: "Innovation Inc", value: "$25,600", status: "Active" }
            ].map((customer, index) => (
              <div key={index} style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '16px',
                borderRadius: 'var(--radius)',
                transition: 'all 0.3s ease',
                cursor: 'pointer'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--muted)'
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent'
              }}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '16px'
                }}>
                  <Avatar style={{
                    height: '40px',
                    width: '40px',
                    border: '2px solid var(--border)'
                  }}>
                    <AvatarImage src="" />
                    <AvatarFallback style={{
                      background: 'linear-gradient(135deg, var(--chart-1), var(--chart-5))',
                      color: 'white',
                      fontFamily: 'var(--font-family)',
                      fontSize: 'var(--text-label)',
                      fontWeight: 'var(--font-weight-medium)'
                    }}>
                      {customer.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p style={{
                      fontFamily: 'var(--font-family)',
                      fontSize: 'var(--text-base)',
                      fontWeight: 'var(--font-weight-medium)',
                      color: 'var(--foreground)',
                      margin: '0 0 4px 0'
                    }}>
                      {customer.name}
                    </p>
                    <p style={{
                      fontFamily: 'var(--font-family)',
                      fontSize: 'var(--text-label)',
                      fontWeight: 'var(--font-weight-normal)',
                      color: 'var(--muted-foreground)',
                      margin: 0
                    }}>
                      {customer.company}
                    </p>
                  </div>
                </div>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  textAlign: 'right'
                }}>
                  <div>
                    <p style={{
                      fontFamily: 'var(--font-family)',
                      fontSize: 'var(--text-base)',
                      fontWeight: 'var(--font-weight-semibold)',
                      color: 'var(--foreground)',
                      margin: '0 0 4px 0'
                    }}>
                      {customer.value}
                    </p>
                    <Badge style={{
                      backgroundColor: customer.status === "Active" ? 'var(--chart-2)' : 'var(--chart-1)',
                      color: 'white',
                      border: 'none',
                      borderRadius: 'var(--radius)',
                      fontFamily: 'var(--font-family)',
                      fontSize: 'var(--text-label)',
                      fontWeight: 'var(--font-weight-medium)',
                      padding: '4px 8px'
                    }}>
                      {customer.status}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}