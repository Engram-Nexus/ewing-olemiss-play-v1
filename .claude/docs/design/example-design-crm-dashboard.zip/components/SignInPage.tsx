import { useState } from "react"
import { Button } from "./ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Separator } from "./ui/separator"
import { ArrowLeft, Eye, EyeOff } from "lucide-react"
import { GoogleLogo, AppleLogo } from "./BrandLogos"

interface SignInPageProps {
  onSwitchToSignUp: () => void
  onBack: () => void
}

export function SignInPage({ onSwitchToSignUp, onBack }: SignInPageProps) {
  const [showPassword, setShowPassword] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      // Here you would integrate with Clerk
      console.log("Sign in:", { email, password })
    }, 2000)
  }

  return (
    <div style={{
      width: '100%',
      maxWidth: '400px',
      display: 'flex',
      flexDirection: 'column',
      gap: '24px'
    }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: '16px',
        marginBottom: '8px'
      }}>
        <Button
          onClick={onBack}
          style={{
            backgroundColor: 'var(--secondary)',
            color: 'var(--secondary-foreground)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius)',
            padding: '8px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <ArrowLeft style={{ width: '16px', height: '16px' }} />
        </Button>
        <h1 style={{
          fontSize: 'var(--text-h2)',
          fontWeight: 'var(--font-weight-bold)',
          color: 'var(--foreground)',
          margin: 0
        }}>
          Sign In
        </h1>
      </div>

      {/* Main Card */}
      <Card style={{
        backgroundColor: 'var(--card)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius-card)',
        boxShadow: 'var(--elevation-sm)'
      }}>
        <CardHeader style={{ paddingBottom: '16px' }}>
          <CardTitle style={{
            fontSize: 'var(--text-h3)',
            fontWeight: 'var(--font-weight-semibold)',
            color: 'var(--card-foreground)',
            margin: 0,
            textAlign: 'center'
          }}>
            Welcome back
          </CardTitle>
          <p style={{
            fontSize: 'var(--text-base)',
            color: 'var(--muted-foreground)',
            margin: '8px 0 0 0',
            textAlign: 'center'
          }}>
            Sign in to your account to continue
          </p>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={handleSubmit} style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '24px'
          }}>
            {/* Social Sign In */}
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '12px'
            }}>
              <Button
                type="button"
                style={{
                  backgroundColor: 'var(--secondary)',
                  color: 'var(--secondary-foreground)',
                  border: '1px solid var(--border)',
                  borderRadius: 'var(--radius-button)',
                  padding: '12px 16px',
                  fontSize: 'var(--text-base)',
                  fontWeight: 'var(--font-weight-medium)',
                  cursor: 'pointer',
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '12px',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--muted)'
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--secondary)'
                }}
              >
                <GoogleLogo width={20} height={20} />
                Continue with Google
              </Button>
              
              <Button
                type="button"
                style={{
                  backgroundColor: 'var(--secondary)',
                  color: 'var(--secondary-foreground)',
                  border: '1px solid var(--border)',
                  borderRadius: 'var(--radius-button)',
                  padding: '12px 16px',
                  fontSize: 'var(--text-base)',
                  fontWeight: 'var(--font-weight-medium)',
                  cursor: 'pointer',
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '12px',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--muted)'
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--secondary)'
                }}
              >
                <AppleLogo width={20} height={20} />
                Continue with Apple
              </Button>
            </div>

            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '16px'
            }}>
              <Separator style={{ flex: 1 }} />
              <span style={{
                fontSize: 'var(--text-label)',
                color: 'var(--muted-foreground)',
                fontWeight: 'var(--font-weight-medium)'
              }}>
                or
              </span>
              <Separator style={{ flex: 1 }} />
            </div>

            {/* Email Field */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <Label htmlFor="email" style={{
                fontSize: 'var(--text-label)',
                fontWeight: 'var(--font-weight-medium)',
                color: 'var(--foreground)'
              }}>
                Email address
              </Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                required
                style={{
                  backgroundColor: 'var(--input-background)',
                  border: '1px solid var(--border)',
                  borderRadius: 'var(--radius)',
                  padding: '12px 16px',
                  fontSize: 'var(--text-base)',
                  color: 'var(--foreground)'
                }}
              />
            </div>

            {/* Password Field */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <Label htmlFor="password" style={{
                fontSize: 'var(--text-label)',
                fontWeight: 'var(--font-weight-medium)',
                color: 'var(--foreground)'
              }}>
                Password
              </Label>
              <div style={{ position: 'relative' }}>
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  required
                  style={{
                    backgroundColor: 'var(--input-background)',
                    border: '1px solid var(--border)',
                    borderRadius: 'var(--radius)',
                    padding: '12px 16px',
                    paddingRight: '48px',
                    fontSize: 'var(--text-base)',
                    color: 'var(--foreground)',
                    width: '100%'
                  }}
                />
                <Button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  style={{
                    position: 'absolute',
                    right: '12px',
                    top: '50%',
                    transform: 'translateY(-50%)',
                    backgroundColor: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    padding: '4px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  {showPassword ? (
                    <EyeOff style={{ width: '16px', height: '16px', color: 'var(--muted-foreground)' }} />
                  ) : (
                    <Eye style={{ width: '16px', height: '16px', color: 'var(--muted-foreground)' }} />
                  )}
                </Button>
              </div>
            </div>

            {/* Forgot Password */}
            <div style={{ textAlign: 'right' }}>
              <button
                type="button"
                style={{
                  backgroundColor: 'transparent',
                  border: 'none',
                  color: 'var(--primary)',
                  fontSize: 'var(--text-label)',
                  fontWeight: 'var(--font-weight-medium)',
                  cursor: 'pointer',
                  textDecoration: 'underline'
                }}
              >
                Forgot password?
              </button>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={isLoading || !email || !password}
              style={{
                backgroundColor: isLoading || !email || !password ? 'var(--muted)' : 'var(--primary)',
                color: isLoading || !email || !password ? 'var(--muted-foreground)' : 'var(--primary-foreground)',
                border: 'none',
                borderRadius: 'var(--radius-button)',
                padding: '16px 24px',
                fontSize: 'var(--text-base)',
                fontWeight: 'var(--font-weight-medium)',
                cursor: isLoading || !email || !password ? 'not-allowed' : 'pointer',
                width: '100%',
                transition: 'all 0.2s ease'
              }}
            >
              {isLoading ? 'Signing in...' : 'Sign In'}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Sign Up Link */}
      <div style={{
        textAlign: 'center',
        backgroundColor: 'var(--card)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius)',
        padding: '16px'
      }}>
        <span style={{
          fontSize: 'var(--text-base)',
          color: 'var(--muted-foreground)'
        }}>
          Don't have an account?{' '}
        </span>
        <button
          onClick={onSwitchToSignUp}
          style={{
            backgroundColor: 'transparent',
            border: 'none',
            color: 'var(--primary)',
            fontSize: 'var(--text-base)',
            fontWeight: 'var(--font-weight-medium)',
            cursor: 'pointer',
            textDecoration: 'underline'
          }}
        >
          Sign up
        </button>
      </div>
    </div>
  )
}