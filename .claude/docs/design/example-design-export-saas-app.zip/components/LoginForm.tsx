import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Eye, EyeOff, Zap, Mail, Lock, Rocket } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { User, PERSONALITY_TRAITS } from '../types/User';

interface LoginFormProps {
  onLogin: (user: User) => void;
  onSwitchToRegister: () => void;
}

export function LoginForm({ onLogin, onSwitchToRegister }: LoginFormProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isDemoLoading, setIsDemoLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate login delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Mock user creation with random personality
    const randomPersonality = PERSONALITY_TRAITS[Math.floor(Math.random() * PERSONALITY_TRAITS.length)];
    
    const mockUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      email,
      username: email.split('@')[0],
      displayName: email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1),
      avatar: `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${email}`,
      personality: randomPersonality,
      stats: {
        notesCreated: Math.floor(Math.random() * 100) + 10,
        daysActive: Math.floor(Math.random() * 365) + 1,
        favoriteTime: ['morning', 'afternoon', 'evening', 'late night'][Math.floor(Math.random() * 4)],
        productivity: Math.floor(Math.random() * 100) + 1
      },
      preferences: {
        theme: 'light',
        notifications: true,
        publicProfile: false
      },
      joinDate: new Date().toISOString()
    };

    onLogin(mockUser);
    setIsLoading(false);
  };

  const handleDemoAccess = async () => {
    setIsDemoLoading(true);

    // Simulate demo access delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Create demo user with random personality
    const randomPersonality = PERSONALITY_TRAITS[Math.floor(Math.random() * PERSONALITY_TRAITS.length)];
    const demoNames = ['Alex Demo', 'Casey Explorer', 'Jordan Tester', 'Riley Guest', 'Sage Visitor'];
    const randomName = demoNames[Math.floor(Math.random() * demoNames.length)];
    const username = randomName.toLowerCase().replace(' ', '_');

    const demoUser: User = {
      id: 'demo_' + Math.random().toString(36).substr(2, 9),
      email: `${username}@demo.blinklist.com`,
      username: username,
      displayName: randomName,
      avatar: `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${username}`,
      personality: randomPersonality,
      stats: {
        notesCreated: Math.floor(Math.random() * 50) + 25,
        daysActive: Math.floor(Math.random() * 100) + 30,
        favoriteTime: ['morning', 'afternoon', 'evening', 'late night'][Math.floor(Math.random() * 4)],
        productivity: Math.floor(Math.random() * 40) + 60 // Demo users have good productivity
      },
      preferences: {
        theme: 'light',
        notifications: true,
        publicProfile: true
      },
      joinDate: new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000).toISOString() // Random date within last 90 days
    };

    onLogin(demoUser);
    setIsDemoLoading(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="backdrop-blur-sm bg-white/80 shadow-xl border-0">
        <CardHeader className="text-center space-y-4">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="mx-auto w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center"
          >
            <Zap className="w-8 h-8 text-white" />
          </motion.div>
          <div>
            <CardTitle className="text-2xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Welcome back to Blinklist
            </CardTitle>
            <p className="text-gray-600 mt-2">Ready to capture your next brilliant idea? ✨</p>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  type="email"
                  placeholder="your-awesome-email@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 border-gray-200 focus:border-purple-300"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Your secret password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 pr-10 border-gray-200 focus:border-purple-300"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
              disabled={isLoading}
            >
              {isLoading ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full"
                />
              ) : (
                "Sign In & Start Creating! 🚀"
              )}
            </Button>
          </form>

          {/* Demo Access Button */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-gray-300" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-2 text-gray-500">Or</span>
            </div>
          </div>

          <Button
            onClick={handleDemoAccess}
            disabled={isDemoLoading}
            variant="outline"
            className="w-full border-2 border-dashed border-purple-300 hover:border-purple-400 hover:bg-purple-50 text-purple-700"
          >
            {isDemoLoading ? (
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="w-4 h-4 border-2 border-purple-300/20 border-t-purple-600 rounded-full mr-2"
              />
            ) : (
              <Rocket className="w-4 h-4 mr-2" />
            )}
            Try Demo - No signup needed! 🎯
          </Button>

          <div className="text-center space-y-2">
            <p className="text-sm text-gray-600">
              New to our creative universe?
            </p>
            <Button
              variant="ghost"
              onClick={onSwitchToRegister}
              className="text-purple-600 hover:text-purple-700 hover:bg-purple-50"
            >
              Join the Blinklist family! 💜
            </Button>
          </div>

          <div className="text-xs text-center text-gray-500 space-y-1">
            <p>✨ Demo credentials: any email + any password ✨</p>
            <p>🎭 Your personality will be randomly assigned!</p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}