import { 
  Users, 
  Calendar, 
  BarChart3, 
  Settings, 
  Phone, 
  Mail, 
  FileText,
  Home
} from "lucide-react"
import { Link, useLocation, useNavigate } from "react-router-dom"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "./ui/sidebar"
import { ShimmerMenuItem } from "./ShimmerMenuItem"

interface DashboardSidebarProps {
  children: React.ReactNode
  currentPage: string
}

const items = [
  {
    title: "Dashboard",
    key: "dashboard",
    path: "/",
    icon: Home,
  },
  {
    title: "Customers",
    key: "customers", 
    path: "/customers",
    icon: Users,
  },
  {
    title: "Activities",
    key: "activities",
    path: "/activities",
    icon: Calendar,
  },
  {
    title: "Reports",
    key: "reports",
    path: "/reports",
    icon: BarChart3,
  },
  {
    title: "Communications",
    key: "communications",
    path: "/communications",
    icon: Mail,
  },
  {
    title: "Calls",
    key: "calls",
    path: "/calls",
    icon: Phone,
  },
  {
    title: "Documents",
    key: "documents",
    path: "/documents",
    icon: FileText,
  },
]

export function DashboardSidebar({ children, currentPage }: DashboardSidebarProps) {
  const location = useLocation()
  const navigate = useNavigate()
  
  const getCurrentPageTitle = () => {
    // Handle preview_page.html by treating it as dashboard
    if (location.pathname === "/preview_page.html") return "CRM Dashboard"
    if (currentPage === "settings" || location.pathname.startsWith("/settings")) return "Settings"
    if (currentPage === "customer-profile" || location.pathname.startsWith("/customer/")) return "Customer Profile"
    
    const currentItem = items.find(item => item.key === currentPage)
    return currentItem ? currentItem.title : "CRM Dashboard"
  }

  return (
    <SidebarProvider>
      <Sidebar style={{
        backgroundColor: 'var(--sidebar)',
        borderRight: '1px solid var(--sidebar-border)',
        backdropFilter: 'blur(20px)'
      }}>
        <SidebarContent style={{ backgroundColor: 'transparent' }}>
          <SidebarGroup>
            <SidebarGroupLabel style={{
              color: 'var(--sidebar-primary)',
              fontFamily: 'var(--font-family)',
              fontSize: 'var(--text-h4)',
              fontWeight: 'var(--font-weight-semibold)',
              padding: '24px 16px'
            }}>
              CRM Dashboard
            </SidebarGroupLabel>
            <SidebarGroupContent style={{ padding: '0 12px' }}>
              <SidebarMenu style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {items.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <Link 
                      to={item.path} 
                      style={{ 
                        textDecoration: 'none', 
                        width: '100%',
                        display: 'block'
                      }}
                      onClick={(e) => {
                        e.preventDefault()
                        navigate(item.path)
                      }}
                    >
                      <ShimmerMenuItem
                        icon={item.icon}
                        title={item.title}
                        isActive={currentPage === item.key}
                        onClick={() => navigate(item.path)}
                      />
                    </Link>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter style={{ backgroundColor: 'transparent', padding: '12px' }}>
          <SidebarMenu>
            <SidebarMenuItem>
              <Link 
                to="/settings" 
                style={{ 
                  textDecoration: 'none', 
                  width: '100%',
                  display: 'block'
                }}
                onClick={(e) => {
                  e.preventDefault()
                  navigate("/settings")
                }}
              >
                <ShimmerMenuItem
                  icon={Settings}
                  title="Settings"
                  isActive={currentPage === "settings" || location.pathname.startsWith("/settings")}
                  onClick={() => navigate("/settings")}
                />
              </Link>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarFooter>
      </Sidebar>
      <main style={{ 
        flex: 1, 
        overflow: 'auto', 
        backgroundColor: 'transparent' 
      }}>
        <div style={{
          backgroundColor: 'var(--card)',
          borderBottom: '1px solid var(--border)',
          backdropFilter: 'blur(20px)'
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '16px',
            padding: '24px'
          }}>
            <SidebarTrigger style={{
              backgroundColor: 'var(--card)',
              borderRadius: 'var(--radius)',
              padding: '8px',
              border: '1px solid var(--border)',
              backdropFilter: 'blur(12px)',
              transition: 'all 0.3s ease-out',
              cursor: 'pointer'
            }} />
            <h1 style={{
              fontFamily: 'var(--font-family)',
              fontSize: 'var(--text-h2)',
              fontWeight: 'var(--font-weight-semibold)',
              color: 'var(--foreground)',
              margin: 0
            }}>
              {getCurrentPageTitle()}
            </h1>
          </div>
        </div>
        <div style={{ padding: '24px' }}>
          {children}
        </div>
      </main>
    </SidebarProvider>
  )
}