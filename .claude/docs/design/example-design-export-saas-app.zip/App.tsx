import React, { useState, useEffect } from 'react';
import { LoginForm } from './components/LoginForm';
import { RegisterForm } from './components/RegisterForm';
import { UserDashboard } from './components/UserDashboard';
import { User } from './types/User';

type AuthMode = 'login' | 'register' | 'dashboard';

export default function App() {
  const [authMode, setAuthMode] = useState<AuthMode>('login');
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  useEffect(() => {
    // Check for existing user session in localStorage
    const savedUser = localStorage.getItem('blinklistUser');
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
      setAuthMode('dashboard');
    }
  }, []);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('blinklistUser', JSON.stringify(user));
    setAuthMode('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('blinklistUser');
    setAuthMode('login');
  };

  const switchToRegister = () => setAuthMode('register');
  const switchToLogin = () => setAuthMode('login');

  if (authMode === 'dashboard' && currentUser) {
    return <UserDashboard user={currentUser} onLogout={handleLogout} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-yellow-50">
      <div className="flex items-center justify-center min-h-screen p-4">
        <div className="w-full max-w-md">
          {authMode === 'login' ? (
            <LoginForm 
              onLogin={handleLogin} 
              onSwitchToRegister={switchToRegister}
            />
          ) : (
            <RegisterForm 
              onRegister={handleLogin}
              onSwitchToLogin={switchToLogin}
            />
          )}
        </div>
      </div>
    </div>
  );
}