import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Label } from "./ui/label"
import { Switch } from "./ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select"
import { Separator } from "./ui/separator"
import { Save, Moon, Sun } from "lucide-react"

export function PreferencesSettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2>Preferences</h2>
        <p className="text-muted-foreground">
          Customize your experience and interface preferences
        </p>
      </div>

      {/* Appearance */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle>Appearance</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label className="text-base">Theme</Label>
              <p className="text-sm text-muted-foreground mb-4">
                Choose your preferred color scheme
              </p>
              <div className="grid grid-cols-3 gap-4 max-w-md">
                <div className="flex flex-col items-center gap-2 p-4 bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border border-white/20 rounded-lg cursor-pointer hover:bg-white/80 dark:hover:bg-gray-700/80 transition-all duration-300">
                  <Sun className="h-5 w-5" />
                  <span className="text-sm">Light</span>
                </div>
                <div className="flex flex-col items-center gap-2 p-4 bg-primary text-primary-foreground rounded-lg cursor-pointer shadow-lg shadow-primary/20">
                  <Moon className="h-5 w-5" />
                  <span className="text-sm">Dark</span>
                </div>
                <div className="flex flex-col items-center gap-2 p-4 bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border border-white/20 rounded-lg cursor-pointer hover:bg-white/80 dark:hover:bg-gray-700/80 transition-all duration-300">
                  <div className="h-5 w-5 bg-gradient-to-r from-muted to-primary rounded"></div>
                  <span className="text-sm">Auto</span>
                </div>
              </div>
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Compact Mode</Label>
                <p className="text-sm text-muted-foreground">
                  Reduce spacing for more content on screen
                </p>
              </div>
              <Switch />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Animations</Label>
                <p className="text-sm text-muted-foreground">
                  Enable smooth transitions and animations
                </p>
              </div>
              <Switch defaultChecked />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Language & Region */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle>Language & Region</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label>Language</Label>
              <Select defaultValue="en">
                <SelectTrigger className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-white/20">
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="es">Español</SelectItem>
                  <SelectItem value="fr">Français</SelectItem>
                  <SelectItem value="de">Deutsch</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Timezone</Label>
              <Select defaultValue="est">
                <SelectTrigger className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-white/20">
                  <SelectItem value="pst">Pacific Time (PST)</SelectItem>
                  <SelectItem value="mst">Mountain Time (MST)</SelectItem>
                  <SelectItem value="cst">Central Time (CST)</SelectItem>
                  <SelectItem value="est">Eastern Time (EST)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Date Format</Label>
              <Select defaultValue="mdy">
                <SelectTrigger className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-white/20">
                  <SelectItem value="mdy">MM/DD/YYYY</SelectItem>
                  <SelectItem value="dmy">DD/MM/YYYY</SelectItem>
                  <SelectItem value="ymd">YYYY-MM-DD</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Time Format</Label>
              <Select defaultValue="12h">
                <SelectTrigger className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-white/20">
                  <SelectItem value="12h">12 Hour</SelectItem>
                  <SelectItem value="24h">24 Hour</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Dashboard */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle>Dashboard</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Auto-refresh Data</Label>
                <p className="text-sm text-muted-foreground">
                  Automatically update dashboard metrics
                </p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="space-y-2">
              <Label>Default Dashboard View</Label>
              <Select defaultValue="overview">
                <SelectTrigger className="max-w-xs bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-white/20">
                  <SelectItem value="overview">Overview</SelectItem>
                  <SelectItem value="customers">Customers</SelectItem>
                  <SelectItem value="activities">Activities</SelectItem>
                  <SelectItem value="reports">Reports</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Items per Page</Label>
              <Select defaultValue="25">
                <SelectTrigger className="max-w-xs bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-white/20">
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="25">25</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                  <SelectItem value="100">100</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button className="bg-primary text-primary-foreground rounded-xl hover:scale-105 transition-all duration-300 px-6">
          <Save className="h-4 w-4 mr-2" />
          Save Preferences
        </Button>
      </div>
    </div>
  )
}