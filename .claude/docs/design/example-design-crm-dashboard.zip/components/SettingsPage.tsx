import { useState } from "react"
import { SettingsLayout } from "./SettingsLayout"
import { ProfileSettingsPage } from "./ProfileSettingsPage"
import { PreferencesSettingsPage } from "./PreferencesSettingsPage"
import { SecuritySettingsPage } from "./SecuritySettingsPage"
import { NotificationSettingsPage } from "./NotificationSettingsPage"
import { StyleGuidePage } from "./StyleGuidePage"
import { Card, CardContent } from "./ui/card"
import { HelpCircle } from "lucide-react"

interface SettingsPageProps {
  onBack: () => void
}

export function SettingsPage({ onBack }: SettingsPageProps) {
  const [currentPage, setCurrentPage] = useState("profile")

  const renderSettingsPage = () => {
    switch (currentPage) {
      case "profile":
        return <ProfileSettingsPage />
      case "preferences":
        return <PreferencesSettingsPage />
      case "security":
        return <SecuritySettingsPage />
      case "notifications":
        return <NotificationSettingsPage />
      case "style-guide":
        return <StyleGuidePage />
      case "help":
        return (
          <div className="space-y-6">
            <div>
              <h2>Help & Support</h2>
              <p className="text-muted-foreground">
                Get help and contact our support team
              </p>
            </div>
            
            <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
              <CardContent className="p-6 text-center">
                <HelpCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h4>Need Help?</h4>
                <p className="text-muted-foreground text-sm mb-4">
                  Our support team is here to help you with any questions or issues.
                </p>
                <div className="space-y-2">
                  <p className="text-sm">
                    <strong>Email:</strong> support@crm-app.com
                  </p>
                  <p className="text-sm">
                    <strong>Phone:</strong> +1 (800) 123-4567
                  </p>
                  <p className="text-sm">
                    <strong>Hours:</strong> Monday - Friday, 9AM - 6PM EST
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        )
      default:
        return <ProfileSettingsPage />
    }
  }

  return (
    <SettingsLayout 
      onBack={onBack} 
      currentPage={currentPage} 
      onPageChange={setCurrentPage}
    >
      {renderSettingsPage()}
    </SettingsLayout>
  )
}