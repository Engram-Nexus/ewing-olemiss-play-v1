import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Switch } from "./ui/switch"
import { Badge } from "./ui/badge"
import { Separator } from "./ui/separator"
import { Shield, Key, Smartphone, Eye, EyeOff, AlertTriangle } from "lucide-react"
import { useState } from "react"

export function SecuritySettingsPage() {
  const [showPassword, setShowPassword] = useState(false)

  return (
    <div className="space-y-6">
      <div>
        <h2>Security Settings</h2>
        <p className="text-muted-foreground">
          Manage your password and security preferences
        </p>
      </div>

      {/* Password */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="h-5 w-5" />
            Password
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="current-password">Current Password</Label>
              <div className="relative">
                <Input 
                  id="current-password" 
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter current password"
                  className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="new-password">New Password</Label>
              <Input id="new-password" type="password" placeholder="Enter new password" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50" />
              <p className="text-sm text-muted-foreground">
                Password must be at least 8 characters with uppercase, lowercase, and numbers
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirm-password">Confirm Password</Label>
              <Input id="confirm-password" type="password" placeholder="Confirm new password" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/50" />
            </div>

            <Button className="w-full md:w-auto bg-primary text-primary-foreground rounded-xl hover:scale-105 transition-all duration-300">Update Password</Button>
          </div>
        </CardContent>
      </Card>

      {/* Two-Factor Authentication */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Two-Factor Authentication
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Label>SMS Authentication</Label>
                <Badge variant="outline" className="text-green-600 border-green-600 bg-green-50 dark:bg-green-900/20">Enabled</Badge>
              </div>
              <p className="text-sm text-muted-foreground">
                Receive verification codes via SMS to +1 (555) ***-4567
              </p>
            </div>
            <Switch defaultChecked />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Label>Authenticator App</Label>
                <Badge variant="outline">Not Setup</Badge>
              </div>
              <p className="text-sm text-muted-foreground">
                Use an authenticator app for more secure 2FA
              </p>
            </div>
            <Button variant="outline" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl hover:scale-105 transition-all duration-300">
              <Smartphone className="h-4 w-4 mr-2" />
              Setup
            </Button>
          </div>

          <div className="bg-white/30 dark:bg-white/5 p-4 rounded-lg">
            <div className="flex gap-3">
              <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-medium text-sm">Backup Codes</p>
                <p className="text-sm text-muted-foreground">
                  Make sure to save your backup codes in a secure location. You have 8 unused codes remaining.
                </p>
                <Button variant="ghost" size="sm" className="p-0 h-auto text-xs hover:bg-white/20 dark:hover:bg-white/10">
                  View Backup Codes
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Sessions */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle>Active Sessions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-white/30 dark:bg-white/5 rounded-lg">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <p className="font-medium">Current Session</p>
                  <Badge className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400 border-0">Active</Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  Chrome on macOS • New York, NY • Last active: Now
                </p>
              </div>
              <Button variant="outline" disabled className="bg-white/40 dark:bg-gray-800/40">Current</Button>
            </div>

            <div className="flex items-center justify-between p-4 bg-white/30 dark:bg-white/5 rounded-lg">
              <div className="space-y-1">
                <p className="font-medium">Mobile App</p>
                <p className="text-sm text-muted-foreground">
                  iPhone App • Last active: 2 hours ago
                </p>
              </div>
              <Button variant="outline" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl hover:scale-105 transition-all duration-300">Revoke</Button>
            </div>

            <div className="flex items-center justify-between p-4 bg-white/30 dark:bg-white/5 rounded-lg">
              <div className="space-y-1">
                <p className="font-medium">Safari on iPad</p>
                <p className="text-sm text-muted-foreground">
                  Last active: Yesterday at 3:42 PM
                </p>
              </div>
              <Button variant="outline" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-md border-white/20 rounded-xl hover:scale-105 transition-all duration-300">Revoke</Button>
            </div>
          </div>

          <Button variant="destructive" className="w-full rounded-xl hover:scale-105 transition-all duration-300">
            Sign Out All Other Sessions
          </Button>
        </CardContent>
      </Card>

      {/* Login Alerts */}
      <Card className="bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl border-0 shadow-lg shadow-black/5 transition-all duration-300 hover:shadow-xl">
        <CardHeader>
          <CardTitle>Login Alerts</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label>Email Login Notifications</Label>
              <p className="text-sm text-muted-foreground">
                Get notified when someone signs in to your account
              </p>
            </div>
            <Switch defaultChecked />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label>Suspicious Activity Alerts</Label>
              <p className="text-sm text-muted-foreground">
                Get notified of unusual login attempts or locations
              </p>
            </div>
            <Switch defaultChecked />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}