import { ReactNode } from "react"
import { LucideIcon } from "lucide-react"

interface ShimmerMenuItemProps {
  icon: LucideIcon
  title: string
  isActive: boolean
  onClick: () => void
}

export function ShimmerMenuItem({ icon: Icon, title, isActive, onClick }: ShimmerMenuItemProps) {
  return (
    <button
      onClick={onClick}
      style={{
        position: 'relative',
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        height: '48px',
        padding: '0 16px',
        borderRadius: 'var(--radius-button)',
        fontFamily: 'var(--font-family)',
        fontSize: 'var(--text-base)',
        fontWeight: 'var(--font-weight-medium)',
        transition: 'all 0.3s ease-out',
        overflow: 'hidden',
        border: 'none',
        cursor: 'pointer',
        backgroundColor: isActive ? 'var(--sidebar-primary)' : 'transparent',
        color: isActive ? 'var(--sidebar-primary-foreground)' : 'var(--sidebar-foreground)',
        boxShadow: isActive ? 'var(--elevation-sm)' : 'none'
      }}
      className="group"
      onMouseEnter={(e) => {
        if (!isActive) {
          e.currentTarget.style.backgroundColor = 'var(--secondary)'
          e.currentTarget.style.color = 'var(--sidebar-foreground)'
        }
      }}
      onMouseLeave={(e) => {
        if (!isActive) {
          e.currentTarget.style.backgroundColor = 'transparent'
          e.currentTarget.style.color = 'var(--sidebar-foreground)'
        }
      }}
    >
      {/* Shimmer effect overlay for active state */}
      {isActive && (
        <>
          {/* Primary shimmer animation overlay */}
          <div
            style={{
              position: 'absolute',
              inset: '0',
              background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.7) 50%, transparent 100%)',
              width: '200%',
              left: '-100%',
              animation: 'shimmer-slide 3s ease-in-out infinite',
              pointerEvents: 'none',
              zIndex: 10
            }}
          />

          {/* Backup pulse animation for visibility */}
          <div 
            style={{
              position: 'absolute',
              inset: '0',
              backgroundColor: 'rgba(255, 255, 255, 0.1)',
              animation: 'shimmer-pulse 2s ease-in-out infinite',
              pointerEvents: 'none',
              zIndex: 5
            }}
          />

          {/* Glass effect overlay */}
          <div
            style={{
              position: 'absolute',
              inset: '0',
              background: 'linear-gradient(to bottom, rgba(255,255,255,0.1) 0%, transparent 50%, rgba(0,0,0,0.05) 100%)',
              backdropFilter: 'blur(4px)',
              pointerEvents: 'none'
            }}
          />
        </>
      )}

      {/* Hover shimmer effect for non-active items */}
      {!isActive && (
        <div 
          className="group-hover:opacity-100"
          style={{
            position: 'absolute',
            inset: '0',
            opacity: 0,
            transition: 'opacity 0.3s',
            pointerEvents: 'none'
          }}
        >
          <div
            style={{
              position: 'absolute',
              inset: '0',
              background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.4) 50%, transparent 100%)',
              width: '200%',
              left: '-100%',
              animation: 'shimmer-slide 1.5s ease-in-out 1'
            }}
          />
        </div>
      )}

      {/* Content */}
      <div style={{
        position: 'relative',
        zIndex: 20,
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        width: '100%'
      }}>
        <Icon style={{
          height: '20px',
          width: '20px'
        }} />
        <span style={{
          fontFamily: 'var(--font-family)',
          fontSize: 'var(--text-base)',
          fontWeight: 'var(--font-weight-medium)'
        }}>
          {title}
        </span>
        {/* Debug indicator for active state */}
        {isActive && (
          <div style={{
            width: '8px',
            height: '8px',
            backgroundColor: 'rgba(255, 255, 255, 0.5)',
            borderRadius: '50%',
            animation: 'shimmer-pulse 2s ease-in-out infinite',
            marginLeft: 'auto'
          }} />
        )}
      </div>

      {/* Active state inner glow effect */}
      {isActive && (
        <div style={{
          position: 'absolute',
          inset: '0',
          borderRadius: 'var(--radius-button)',
          boxShadow: 'inset 0 0 0 1px rgba(255, 255, 255, 0.2)',
          pointerEvents: 'none'
        }} />
      )}
    </button>
  )
}